import React from 'react';

import 'react-native-gesture-handler';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import HomePage from './screens/Home'
import MainGamePage from './screens/MainGame'
import CountryPage from './screens/Country'
import HangmanPage from './screens/Hangman'
import MultiplayerPage from './screens/Multiplayer'
import RulesPage from './screens/Rules'
import TimerPage from './screens/Timer'

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="Home"
        screenOptions={{
          headerStyle: { backgroundColor: '#f5f5f5' },
          headerTintColor: '#000',
          headerTitleStyle: { fontWeight: 'bold' },
        }}>
        {/* home screen */} 
        <Stack.Screen
          name="Home"
          component={HomePage}
          options={{ headerShown: false }}
        />
        {/* main game screen */} 
        <Stack.Screen
          name="Game"
          component={MainGamePage}
          options={{ headerShown: false }}
        />
        {/* insturctions screen */} 
        <Stack.Screen
          name="Rules"
          component={RulesPage}
          options={{ title: 'How to Play' }}
        />
        {/* hangman game screen */} 
        <Stack.Screen
          name="HangmanChallenge"
          component={HangmanPage}
          options={{ headerShown: false }}
        />
        {/* country game screen */} 
        <Stack.Screen
          name="CountryChallenge"
          component={CountryPage}
          options={{ headerShown: false }}
        />
        {/* multiplayer game screen */} 
        <Stack.Screen
          name="Multiplayer"
          component={MultiplayerPage}
          options={{ headerShown: false }}
        />
        {/* timed wordle screen */} 
        <Stack.Screen
          name="Timer"
          component={TimerPage}
          options={{ headerShown: false }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}