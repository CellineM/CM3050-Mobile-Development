import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, Alert, Dimensions, KeyboardAvoidingView, Platform, Modal, TouchableOpacity, ScrollView, Animated, Easing,
} from 'react-native';
import Svg, { Circle, Line } from 'react-native-svg';
import { Ionicons } from '@expo/vector-icons';
import { Audio } from 'expo-av';


// Function to fetch city names using the Mapbox API
const fetchCities = async () => {
  const accessToken = 'pk.eyJ1IjoiY2VsbGluZW1hY2MiLCJhIjoiY2x6ODQxZmRmMGVqbTJrcXlvaXVqMm13cSJ9.ch5vpf5_voqNdiL44qL6dQ'; 
  const url = `https://api.mapbox.com/geocoding/v5/mapbox.places/city.json?access_token=${accessToken}&types=place&proximity=-98.5795,39.8283&limit=10`;

  try {
    const response = await fetch(url); // Fetch data from the API
    const data = await response.json(); // parse to JSON
    return data.features.map((feature) => feature.text); // get the city name
  } catch (error) {
    console.error('Error fetching city names:', error);
    return [];
  }
};

export default function HangmanChallengeScreen({ navigation }) {
  const [chosenCity, setChosenCity] = useState('');
  const [shownLetters, setShownLetters] = useState([]);
  const [currentInput, setCurrentInput] = useState('');
  const [wrongGuesses, setWrongGuesses] = useState(0);
  const [shownMessage, setShownMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [showPopup, setPopup] = useState(false);
  const maxGuesses = 6;

  const { width, height } = Dimensions.get('window'); 
  const gradientColour = useState(new Animated.Value(0))[0]; // Animated value to create gradient background animation

  // Music object that will be tracked globally in the component
  let music;

  useEffect(() => {
    const getCities = async () => {
      const city = await fetchCities();
      if (city.length > 0) {
        const randomCity = city[Math.floor(Math.random() * city.length)]; // Pick a random city from the fetched data
        const formattedCity = randomCity.toUpperCase(); // Format city name to uppercase
        setChosenCity(formattedCity);
        setShownLetters(formattedCity.split('').map((char) => (char === ' ' ? ' ' : '_'))); // Initialize shown letters
        setLoading(false);
      } else {
        Alert.alert('Error', 'No cities found.');
        setLoading(false);
      }
    };

    const playMusic = async () => {
      const { sound } = await Audio.Sound.createAsync(
        require('../assets/pinkvenom.mp3'), // Ensure the file is in the correct path
        { shouldPlay: true, isLooping: true }
      );
      music = sound;
    };

    getCities();
    playMusic();

    // Animate the gradient
    Animated.loop(
      Animated.timing(gradientColour, {
        toValue: 1, // Animate to a value of 1
        duration: 8000, // Animation duration of 8 seconds
        easing: Easing.linear,
        useNativeDriver: false,
      })
    ).start(); // Start the gradient animation

    return () => {
      // Cleanup function to stop and unload the sound when the component unmounts or on navigation
      if (music) {
        music.stopAsync();
        music.unloadAsync();
      }
    };
  }, [gradientColour]);

  // Stop the music when navigating home
  const handleHome = async () => {
    if (music) {
      await music.stopAsync(); // Stop the music
      await music.unloadAsync(); // Unload the music from memory
    }
    navigation.navigate('Home'); // Navigate back to the 'Home' screen
  };

// Handle letter press on the virtual keyboard
  const handleLetterPress = (letter) => {
    setCurrentInput(letter); // Set the current input to the pressed letter
    handleGuess(letter);
  };

  const handleGuess = (guess) => {
    // validate and must be only one letter each time
    if (guess.length !== 1 || !/^[a-zA-Z]$/.test(guess)) {
      setShownMessage('Please enter only 1 letter.');
      return;
    }

    const upperGuess = guess.toUpperCase(); // Convert guess to uppercase for comparison
    setCurrentInput('');

    // checking if it is correct
    if (chosenCity.includes(upperGuess)) {
      const newShownLetters = shownLetters.slice(); // Create a copy of shown letters
      chosenCity.split('').forEach((letter, index) => {
        if (letter === upperGuess) {
          newShownLetters[index] = upperGuess; // Reveal the correctly guessed letter
        }
      });
      setShownLetters(newShownLetters);

      if (newShownLetters.join('') === chosenCity) {
        setShownMessage('Congratulations! You got the CITY!'); // the message when the player win
        setPopup(true);
      } else {
        setShownMessage('Good guess!'); // when the player got the correct letter
      }
    } else {
      setWrongGuesses(wrongGuesses + 1);

      if (wrongGuesses + 1 === maxGuesses) {
        setShownMessage(`Game Over! The city was ${chosenCity}`); // when the player lost, message will show this message
        setPopup(true);
      } else {
        setShownMessage('EEEHHH WRONG!. Try again!');
      }
    }
  };

// Restart the game by resetting the state
  const handleRestart = () => {
    setLoading(true);
    setWrongGuesses(0);
    setCurrentInput('');
    setShownMessage('');
    setPopup(false);

    const getCities = async () => {
      const city = await fetchCities(); // get the new city again
      if (city.length > 0) {
        const randomCity = city[Math.floor(Math.random() * city.length)];
        setChosenCity(randomCity.toUpperCase());
        setShownLetters(Array(randomCity.length).fill('_'));
        setLoading(false);
      } else {
        Alert.alert('Error', 'No cities found.');
        setLoading(false);
      }
    };

    getCities();
  };

// Render the Hangman SVG graphics based on the number of wrong guesses
  const renderHangman = () => {
    switch (wrongGuesses) {
      case 0:
        return null;
      case 1:
        return <Circle cx="100" cy="40" r="10" stroke="black" strokeWidth="2" fill="none" />;
      case 2:
        return (
          <>
            <Circle cx="100" cy="40" r="10" stroke="black" strokeWidth="2" fill="none" />
            <Line x1="100" y1="50" x2="100" y2="90" stroke="black" strokeWidth="2" />
          </>
        );
      case 3:
        return (
          <>
            <Circle cx="100" cy="40" r="10" stroke="black" strokeWidth="2" fill="none" />
            <Line x1="100" y1="50" x2="100" y2="90" stroke="black" strokeWidth="2" />
            <Line x1="100" y1="60" x2="80" y2="70" stroke="black" strokeWidth="2" />
          </>
        );
      case 4:
        return (
          <>
            <Circle cx="100" cy="40" r="10" stroke="black" strokeWidth="2" fill="none" />
            <Line x1="100" y1="50" x2="100" y2="90" stroke="black" strokeWidth="2" />
            <Line x1="100" y1="60" x2="80" y2="70" stroke="black" strokeWidth="2" />
            <Line x1="100" y1="60" x2="120" y2="70" stroke="black" strokeWidth="2" />
          </>
        );
      case 5:
        return (
          <>
            <Circle cx="100" cy="40" r="10" stroke="black" strokeWidth="2" fill="none" />
            <Line x1="100" y1="50" x2="100" y2="90" stroke="black" strokeWidth="2" />
            <Line x1="100" y1="60" x2="80" y2="70" stroke="black" strokeWidth="2" />
            <Line x1="100" y1="60" x2="120" y2="70" stroke="black" strokeWidth="2" />
            <Line x1="100" y1="90" x2="80" y2="110" stroke="black" strokeWidth="2" />
          </>
        );
      case 6:
        return (
          <>
            <Circle cx="100" cy="40" r="10" stroke="black" strokeWidth="2" fill="none" />
            <Line x1="100" y1="50" x2="100" y2="90" stroke="black" strokeWidth="2" />
            <Line x1="100" y1="60" x2="80" y2="70" stroke="black" strokeWidth="2" />
            <Line x1="100" y1="60" x2="120" y2="70" stroke="black" strokeWidth="2" />
            <Line x1="100" y1="90" x2="80" y2="110" stroke="black" strokeWidth="2" />
            <Line x1="100" y1="90" x2="120" y2="110" stroke="black" strokeWidth="2" />
          </>
        );
      default:
        return null;
    }
  };

  const interpolatedBackgroundColor = gradientColour.interpolate({
    inputRange: [0, 1],
    outputRange: ['#5094ab', '#ab6198'],
  });

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <Text>Loading...</Text>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      keyboardVerticalOffset={0.1 * height}
    >
      <Animated.View style={[styles.animatedBackground, { backgroundColor: interpolatedBackgroundColor }]} />
      <ScrollView contentContainerStyle={styles.scrollViewContent}>
        <TouchableOpacity style={styles.backButton} onPress={handleHome}>
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>
        <View style={styles.innerContainer}>
          <Text style={styles.title}>Hangman Challenge</Text>
          <Text style={styles.instructions}>Guess the city!</Text>

          <Text style={styles.country}>
            {shownLetters.map((letter, index) => (letter === ' ' ? ' ' : letter)).join(' ')}
          </Text>

          <Text style={styles.wrongGuesses}>Incorrect guesses: {wrongGuesses}/{maxGuesses}</Text>

          <View style={styles.keyboard}>
            {'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').map((letter) => (
              <TouchableOpacity
                key={letter}
                style={styles.letterButton}
                onPress={() => handleLetterPress(letter)}
              >
                <Text style={styles.letterButtonText}>{letter}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <Text style={styles.shownMessage}>{shownMessage}</Text>
          <Svg height="200" width="200">
            {renderHangman()}
          </Svg>
          <Modal
            transparent={true}
            visible={showPopup}
            onRequestClose={() => setPopup(false)}
          >
            <View style={styles.modalContainer}>
              <View style={styles.modalContent}>
                <Text style={styles.modalTitle}>Game Over</Text>
                <Text style={styles.modalMessage}>{shownMessage}</Text>
                <TouchableOpacity style={styles.modalButton} onPress={handleRestart}>
                  <Text style={styles.modalButtonText}>Restart</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.modalButton} onPress={handleHome}>
                  <Text style={styles.modalButtonText}>Home</Text>
                </TouchableOpacity>
              </View>
            </View>
          </Modal>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent', // Transparent to show the animated gradient
    justifyContent: 'center',
    alignItems: 'center',
  },
  animatedBackground: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: -1,
  },
  scrollViewContent: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  innerContainer: {
    alignItems: 'center',
    width: '80%',
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    marginTop: '20%',
  },
  instructions: {
    fontSize: 18,
    marginBottom: 10,
    textAlign: 'center',
  },
  country: {
    fontSize: 24,
    letterSpacing: 2,
    marginBottom: 20,
  },
  wrongGuesses: {
    fontSize: 16,
    marginBottom: 20,
  },
  shownMessage: {
    fontSize: 16,
    marginVertical: 20,
    textAlign: 'center',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    width: '80%',
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
    alignItems: 'center',
  },
  modalTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  modalMessage: {
    fontSize: 18,
    marginBottom: 20,
    textAlign: 'center',
  },
  modalButton: {
    backgroundColor: '#007bff',
    padding: 10,
    borderRadius: 5,
    marginVertical: 5,
    width: '100%',
    alignItems: 'center',
  },
  modalButtonText: {
    color: 'white',
    fontSize: 16,
  },
  keyboard: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    width: '100%',
    marginBottom: 10,
    justifyContent: 'center',
  },
  letterButton: {
    width: '13%',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 8,
    backgroundColor: '#e0e0e0',
    borderRadius: 5,
    margin: 1,
  },
  letterButtonText: {
    fontSize: 18,
  },
  backButton: {
    position: 'absolute',
    top: Platform.OS === 'ios' ? 60 : 40,
    left: 5,
    zIndex: 10,
  },
});
