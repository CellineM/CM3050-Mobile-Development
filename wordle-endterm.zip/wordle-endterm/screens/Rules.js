import React from 'react';
import { View, Text, StyleSheet, Button } from 'react-native';

export default function InstructionsScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>How to Play</Text>
      <View style={styles.instructionsContainer}>
        <View style={[styles.instructionBox, styles.greenBox]}>
          <Text style={styles.instructionText}>Green: Correct letter in the correct position.</Text>
        </View>
        <View style={[styles.instructionBox, styles.yellowBox]}>
          <Text style={styles.instructionText}>Yellow: Correct letter in the wrong position.</Text>
        </View>
        <View style={[styles.instructionBox, styles.grayBox]}>
          <Text style={styles.instructionText}>Gray: Letter not in the word.</Text>
        </View>
      </View>
      <Text style={styles.instructions}>
        You have 6 tries to guess the word.
      </Text>
      <Button
        title="Back to Home"
        onPress={() => navigation.goBack()}
        color="#007bff"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  instructionsContainer: {
    marginBottom: 20,
  },
  instructionBox: {
    padding: 10,
    borderRadius: 5,
    marginVertical: 5,
    width: '100%',
  },
  greenBox: {
    backgroundColor: '#6aaa64',
  },
  yellowBox: {
    backgroundColor: '#c9b458',
  },
  grayBox: {
    backgroundColor: '#787c7e',
  },
  instructionText: {
    fontSize: 18,
    color: '#fff',
    textAlign: 'center',
  },
  instructions: {
    fontSize: 18,
    marginBottom: 20,
    textAlign: 'center',
  },
});
