import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, Alert, TouchableOpacity, Image, Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient'; // For gradient background styling
import { useNavigation } from '@react-navigation/native'; // Navigation hook to handle screen transitions

export default function TimedWordleGame() {
  // Game state variables
  const [word, setWord] = useState(''); // Target word to guess
  const [input, setInput] = useState(''); // Current user input
  const [tries, setTries] = useState([]); // Array of guesses and feedback
  const [timeLeft, setTimeLeft] = useState(60); // Timer for the game
  const [timerNum, setTimerNum] = useState(null); // Holds the interval ID for the timer
  const [clickHint, setClickHint] = useState(false); // State to track if the hint has been used
  const navigation = useNavigation(); // React Navigation hook for navigating between screens

  // Start the game with a new word and reset states
  useEffect(() => {
    restart();
  }, []);

  // Timer logic: reduce timeLeft every second
  useEffect(() => {
    if (timeLeft > 0) {
      const id = setInterval(() => {
        setTimeLeft((prevTime) => prevTime - 1); // Reduce timeLeft by 1 second
      }, 1000);
      setTimerNum(id); // Store the interval ID

      return () => clearInterval(id); // Cleanup the interval on unmount or when time runs out
    } else {
      handleTimeOut(); // Handle timeout when timeLeft reaches 0
    }
  }, [timeLeft]);

  // Function to handle when the timer runs out
  const handleTimeOut = () => {
    clearInterval(timerNum); // Stop the timer
    Alert.alert(
      'Game Over!',
      'You ran out of time!',
      [
        { text: 'Restart', onPress: restart }, // Option to restart the game
        { text: 'Home', onPress: () => navigation.navigate('Home') }, // Option to return to the home screen
      ]
    );
  };

  // Check if the user input is correct or provide feedback
  const checkInput = () => {
    if (input.length !== 6) {
      Alert.alert('Invalid Guess', 'Your guess must be a 6-letter word.');
      return;
    }

    const newFeedback = input.split('').map(letter => ({ letter, color: 'gray' })); // Start feedback as all gray
    const wordArray = word.split(''); // Split the target word into an array

    // First pass to mark correct letters (green)
    newFeedback.forEach((feedback, index) => {
      if (feedback.letter === wordArray[index]) {
        feedback.color = 'green'; // Correct letter in correct position
        wordArray[index] = null; // Mark the letter as used
      }
    });

    // Second pass to mark present letters (yellow)
    newFeedback.forEach((feedback, index) => {
      if (feedback.color !== 'green' && wordArray.includes(feedback.letter)) {
        feedback.color = 'yellow'; // Correct letter but wrong position
        wordArray[wordArray.indexOf(feedback.letter)] = null; // Mark the letter as used
      }
    });

    setTries([...tries, newFeedback]); // Update tries with the new feedback

    // Check if the input is correct
    if (input.toLowerCase() === word.toLowerCase()) {
      Alert.alert(
        'Congratulations!',
        'You guessed the word correctly!',
        [{ text: 'Restart', onPress: restart }, { text: 'Home', onPress: () => navigation.navigate('Home') }]
      );
    } else if (tries.length >= 5) {
      // Game over if user used all 6 tries
      Alert.alert(
        'Game Over!',
        `The correct word was: ${word}`,
        [{ text: 'Restart', onPress: restart }, { text: 'Home', onPress: () => navigation.navigate('Home') }]
      );
    } else {
      setInput(''); // Reset the input if not guessed correctly
    }
  };

  // Handle letter input
  const handleInput = (input) => {
    if (input.length < 6) {
      setInput((prevGuess) => prevGuess + input); // Add letter to the input if less than 6 characters
    }
  };

  // Handle deleting the last letter from the input
  const handleDelete = () => {
    setInput((prevGuess) => prevGuess.slice(0, -1)); // Remove the last letter
  };

  // Handle submitting the guess
  const handleSubmit = () => {
    checkInput(); // Check if the guess is correct
  };

  // Restart the game by resetting the timer, input, tries, and word
  const restart = async () => {
    clearInterval(timerNum); // Clear the timer
    setTries([]); // Reset the guesses
    setTimeLeft(60); // Reset the timer
    setInput(''); // Clear the input
    setClickHint(false); // Reset the hint usage

    // Fetch a new random word
    try {
      const response = await fetch('https://api.datamuse.com/words?sp=??????&max=1000&md=f&fw=g');
      const data = await response.json();
      const randomWord = data[Math.floor(Math.random() * data.length)].word.toUpperCase(); // Get a random word
      setWord(randomWord); // Set the new target word
    } catch (error) {
      Alert.alert('Error', 'Failed to fetch a word. Please try again.');
      setWord('FALLEN'); // Default word if API fails
    }
  };

  // Provide a hint for the first letter
  const giveHint = () => {
    if (clickHint) {
      Alert.alert('Hint Already Used', 'You can only use one hint per game.');
    } else {
      Alert.alert('Hint', `The first letter is: ${word.charAt(0)}`); // Show the first letter as a hint
      setClickHint(true); // Mark hint as used
    }
  };

  // Render the hint button
  const renderHintButton = () => (
    <TouchableOpacity style={styles.hintButton} onPress={giveHint}>
      <Image
        source={require('../assets/eye.png')} // Hint button icon
        style={styles.hintIcon}
        resizeMode="contain"
      />
    </TouchableOpacity>
  );

  return (
    // Gradient background for the game
    <LinearGradient
      colors={['rgba(189, 202, 31, 0.7)', 'rgba(189, 50, 155, 0.7)', 'rgba(79, 182, 129, 0.5 )', 'rgba(189, 50, 155, 0.7)']}
      style={styles.gradientBackground}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }} // Diagonal gradient
    >
      <View style={styles.container}>
        {/* Back Button to return to home */}
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.navigate('Home')}>
          <Image
            source={require('../assets/backArrow.png')} // Back arrow image
            style={styles.backButtonImage}
            resizeMode="contain"
          />
        </TouchableOpacity>

        {/* Game Title */}
        <Text style={styles.title}>Timed Wordle</Text>

        {/* Timer */}
        <Text style={styles.timer}>Time Left: {timeLeft}s</Text>

        {/* Display feedback for the guesses */}
        <View style={styles.triesContainer}>
          {Array.from({ length: 6 }).map((_, rowIndex) => (
            <View key={rowIndex} style={styles.feedbackRow}>
              {Array.from({ length: 6 }).map((_, boxIndex) => (
                <View
                  key={boxIndex}
                  style={[styles.feedbackBox, { backgroundColor: tries[rowIndex] ? tries[rowIndex][boxIndex]?.color : '#fff' }]} // Display feedback colors
                >
                  <Text style={styles.feedbackText}>
                    {tries[rowIndex] ? tries[rowIndex][boxIndex]?.letter : ''} {/* Display letters guessed */}
                  </Text>
                </View>
              ))}
            </View>
          ))}
        </View>

        {/* User input display */}
        <Text style={styles.input}>{input}</Text>

        {/* Render hint button */}
        {renderHintButton()}

        {/* Virtual keyboard for entering letters */}
        <View style={styles.keyboard}>
          {'ABCDEFGH'.split('').map((letter) => (
            <TouchableOpacity key={letter} style={styles.letterBox} onPress={() => handleInput(letter)}>
              <Text style={styles.letterTextBox}>{letter}</Text>
            </TouchableOpacity>
          ))}
          {'IJKLMNOP'.split('').map((letter) => (
            <TouchableOpacity key={letter} style={styles.letterBox} onPress={() => handleInput(letter)}>
              <Text style={styles.letterTextBox}>{letter}</Text>
            </TouchableOpacity>
          ))}
          {'QRSTUVWX'.split('').map((letter) => (
            <TouchableOpacity key={letter} style={styles.letterBox} onPress={() => handleInput(letter)}>
              <Text style={styles.letterTextBox}>{letter}</Text>
            </TouchableOpacity>
          ))}
          {'YZ'.split('').map((letter) => (
            <TouchableOpacity key={letter} style={styles.letterBox} onPress={() => handleInput(letter)}>
              <Text style={styles.letterTextBox}>{letter}</Text>
            </TouchableOpacity>
          ))}
          {/* Delete and Submit buttons */}
          <TouchableOpacity style={styles.letterBox} onPress={handleDelete}>
            <Text style={styles.letterTextBox}>⌫</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.letterBox} onPress={handleSubmit}>
            <Text style={styles.letterTextBox}>➡</Text>
          </TouchableOpacity>
        </View>
      </View>
    </LinearGradient>
  );
}

// Styling for the game components
const styles = StyleSheet.create({
  gradientBackground: {
    flex: 1,
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#fff',
  },
  timer: {
    fontSize: 20,
    color: 'red',
    marginBottom: 20,
  },
  triesContainer: {
    width: '100%',
    marginBottom: 20,
  },
  feedbackRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: 5,
  },
  feedbackBox: {
    width: 30,
    height: 30,
    marginHorizontal: 2,
    borderWidth: 1,
    borderColor: '#ccc',
    justifyContent: 'center',
    alignItems: 'center',
  },
  feedbackText: {
    fontSize: 16,
    color: '#000',
  },
  input: {
    width: '80%',
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    marginBottom: 20,
    borderRadius: 5,
    fontSize: 18,
    textAlign: 'center',
    backgroundColor: '#fff',
  },
  keyboard: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    marginBottom: 0.1 * Dimensions.get('window').width,
  },
  letterBox: {
    width: 0.1 * Dimensions.get('window').width,
    height: 0.1 * Dimensions.get('window').width,
    margin: 2,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 4,
    backgroundColor: '#fff',
    borderColor: '#000',
    borderWidth: 1,
  },
  letterTextBox: {
    fontSize: 0.04 * Dimensions.get('window').width,
    fontWeight: 'bold',
    color: '#000',
  },
  hintButton: {
    width: 0.1 * Dimensions.get('window').width,
    height: 0.1 * Dimensions.get('window').width,
    margin: 2,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fff',
    borderRadius: 4,
    borderWidth: 2,
    borderColor: '#ddd',
  },
  hintIcon: {
    width: '75%',
    height: '75%',
  },
  backButton: {
    position: 'absolute',
    top: 40, // Adjust as needed
    left: 10, // Adjust as needed
  },
  backButtonImage: {
    width: 30,
    height: 30,
    tintColor: '#fff', // Adjust for white back arrow
  },
});
