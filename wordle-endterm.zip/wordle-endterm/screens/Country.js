import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, Alert, Dimensions, TouchableOpacity, KeyboardAvoidingView, Platform, Modal, TextInput } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { Audio } from 'expo-av';

export default function CountryScreen({ navigation }) {
  const [selectedCountry, setSelectedCountry] = useState(''); // country to be guessed
  const [currentInput, setCurrentInput] = useState(''); // track the current input 
  const [guesses, setGuesses] = useState([]); // previous guesses
  const [shownMessage, setShownMessage] = useState(''); // show the message
  const [loading, setLoading] = useState(true); // loading for fetching the country data
  const [popup, setPopup] = useState(false); // the visibility of the pop up messages
  const [gameWon, setGameWon] = useState(false); // Track if the game was won
  const maxGuesses = 6; // maximum number of tries
  const [music, setMusic] = useState();

  const { width, height } = Dimensions.get('window');

  useEffect(() => {
    getCountry();
    return music ? () => music.unloadAsync() : undefined;
  }, []);

  // Function to fetch a random country from an API
  const getCountry = () => {
    setLoading(true);
    fetch('https://restcountries.com/v3.1/all')
      .then(response => response.json())
      .then(data => {
        const countries = data
          .map(country => country.name.common)
          .filter(name => name.length <= 7); // Only include countries with 7 letters or less
        const anyCountry = countries[Math.floor(Math.random() * countries.length)];
        setSelectedCountry(anyCountry.toUpperCase()); // Set the chosen country in uppercase
        setLoading(false);
      })
      .catch(error => {
        Alert.alert("Error", "Failed to load countries.");
        setLoading(false);
      });
  };

  const clickSound = async () => {
    const { music } = await Audio.Sound.createAsync(
      require('../assets/click.mp3')  // Adjust the path to your sound file
    );
    setMusic(music);
    await music.playAsync();
  };

  const handleGuess = () => {
    if (currentInput.length !== selectedCountry.length) {
      // Check if the input length matches the selected country's name length
      setShownMessage(`Please enter a ${selectedCountry.length}-letter country name.`);
      return;
    }

    setGuesses([...guesses, currentInput]);
    setCurrentInput('');

    if (currentInput.toUpperCase() === selectedCountry) {
      setShownMessage('Congratulations! You guessed the country!');
      setGameWon(true);  // Set gameWon to true
      setPopup(true); // popup will be shown
    } else if (guesses.length === maxGuesses - 1) {
      setShownMessage(`Game Over! The country was ${selectedCountry}`);
      setGameWon(false);  // Set gameWon to false
      setPopup(true);
    } else {
      setShownMessage('Try again!');
    }
  };

  const renderGuessRow = (guess) => {
    const letters = guess ? guess.split('') : Array(selectedCountry.length).fill('');

    return (
      <View style={styles.guessRow}>
        {letters.map((letter, index) => (
          <Text key={index} style={[styles.letter, getLetterBack(letter, index, guess)]}>
            {letter}
          </Text>
        ))}
      </View>
    );
  };

  const getLetterBack = (letter, index, guess) => {
    if (!letter) return {};

    if (selectedCountry[index] === letter) {
      return styles.correct; // correct letter, correct position
    }

    if (selectedCountry.includes(letter)) {
      return styles.present; // correct letter, wrong position
    }

    return styles.absent; // wrong letter, not in the country selected
  };

  const handleLetterPress = async (letter) => {
    if (currentInput.length < selectedCountry.length) {
      setCurrentInput(currentInput + letter);
      await clickSound();  // Play the click sound when a letter is pressed
    }
  };

  const handleBackspace = async () => {
    setCurrentInput(currentInput.slice(0, -1));
    await clickSound();  // Play the click sound when backspace is pressed
  };

  const handleNextCountry = () => {
    setGuesses([]); // Clear guesses
    setCurrentInput(''); // Reset input field
    setShownMessage(''); // Clear displayed message
    setPopup(false); // Close popup
    getCountry(); // will fetch from the data to get a new country
  };

// go to home screen
  const handleHome = () => {
    navigation.navigate('Home');
  };

  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <Text>Loading...</Text>
      </View>
    );
  }

  return (
    <LinearGradient
      colors={['#5094ab', '#8d56d1', '#ab6198']}
      style={styles.container}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
    >
      <KeyboardAvoidingView
        style={styles.innerContainer}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={0.1 * height}
      >
        <TouchableOpacity style={styles.backButton} onPress={handleHome}>
          <Ionicons name="arrow-back" size={24} color="white" />
        </TouchableOpacity>

        <View style={styles.innerContainer}>
          {/* Main Title */}
          <Text style={styles.title}>
            {popup ? (gameWon ? 'Congratulations!' : 'Game Over') : 'Country Edition'}
          </Text>
          <Text style={styles.instructions}>Guess the {selectedCountry.length}-letter country!</Text>
          <FlatList
            data={[...guesses, ...Array(maxGuesses - guesses.length).fill(null)]}
            renderItem={({ item }) => renderGuessRow(item)}
            keyExtractor={(item, index) => index.toString()}
          />

          <TextInput
            style={styles.input}
            value={currentInput}
            editable={false}
            placeholder="Your guess will appear here"
            placeholderTextColor="#999"
          />

          {/* On-screen Keyboard */}
          <View style={styles.keyboardContainer}>
            {alphabet.map(letter => (
              <TouchableOpacity
                key={letter}
                style={styles.letterButton}
                onPress={() => handleLetterPress(letter)}
              >
                <Text style={styles.letterButtonText}>{letter}</Text>
              </TouchableOpacity>
            ))}
            <TouchableOpacity style={styles.letterButton} onPress={handleBackspace}>
              <Text style={styles.letterButtonText}>⌫</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.submitButton} onPress={handleGuess}>
              <Text style={styles.submitButtonText}>➡</Text>
            </TouchableOpacity>
          </View>

          <Text style={styles.shownMessage}>{shownMessage}</Text>

          <Modal
            transparent={true}
            visible={popup}
            onRequestClose={() => setPopup(false)}
          >
            <View style={styles.popupContainer}>
              <View style={styles.popupContent}>
                <Text style={styles.popupTitle}>{gameWon ? 'Congratulations!' : 'Game Over'}</Text>
                <Text style={styles.popupMessage}>{shownMessage}</Text>
                <TouchableOpacity style={styles.popupButton} onPress={handleNextCountry}>
                  <Text style={styles.popupButtonText}>Next Country</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.popupButton} onPress={handleHome}>
                  <Text style={styles.popupButtonText}>Home</Text>
                </TouchableOpacity>
              </View>
            </View>
          </Modal>
        </View>
      </KeyboardAvoidingView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  innerContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: '10%',
    padding: 20,
  },
  title: {
    fontSize: 0.07 * Dimensions.get('window').width,
    fontWeight: 'bold',
    marginBottom: 0.02 * Dimensions.get('window').width,
    textAlign: 'center',
    color: 'white',
  },
  instructions: {
    fontSize: 0.04 * Dimensions.get('window').width,
    marginBottom: 0.02 * Dimensions.get('window').width,
    color: 'white',
  },
  guessRow: {
    flexDirection: 'row',
    marginBottom: 0.01 * Dimensions.get('window').width,
  },
  letter: {
    width: 0.1 * Dimensions.get('window').width,
    height: 0.1 * Dimensions.get('window').width,
    textAlign: 'center',
    textAlignVertical: 'center',
    fontSize: 0.05 * Dimensions.get('window').width,
    fontWeight: 'bold',
    borderColor: '#ddd',
    borderWidth: 2,
    margin: 2,
    backgroundColor: '#fff',
  },
  correct: {
    backgroundColor: '#6aaa64',
    color: '#fff',
  },
  present: {
    backgroundColor: '#c9b458',
    color: '#fff',
  },
  absent: {
    backgroundColor: '#787c7e',
    color: '#fff',
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 10,
    width: '80%',
    borderRadius: 5,
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 5,
    elevation: 2,
  },
  submitButton: {
    backgroundColor: '#1E90FF',
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 5,
    marginTop: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 5,
    elevation: 2,
  },
  submitButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  shownMessage: {
    marginTop: 10,
    fontSize: 0.04 * Dimensions.get('window').width,
    fontWeight: 'bold',
    textAlign: 'center',
    color: 'white',
  },
  keyboardContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    marginTop: 10,
  },
  letterButton: {
    alignItems: 'center',
    justifyContent: 'center',
    width: 0.08 * Dimensions.get('window').width,
    height: 0.08 * Dimensions.get('window').width,
    backgroundColor: '#fff',
    borderRadius: 5,
    margin: 3,
  },
  letterButtonText: {
    fontWeight: 'bold',
    fontSize: 16,
    color: '#121213',
  },
  popupContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  popupContent: {
    width: 0.8 * Dimensions.get('window').width,
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
    alignItems: 'center',
  },
  popupTitle: {
    fontSize: 0.05 * Dimensions.get('window').width,
    fontWeight: 'bold',
  },
  popupMessage: {
    fontSize: 0.04 * Dimensions.get('window').width,
    marginVertical: 10,
  },
  popupButton: {
    backgroundColor: '#1E90FF',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    marginTop: 10,
    width: '80%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  popupButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  backButton: {
    position: 'absolute',
    top: Platform.OS === 'ios' ? 60 : 40,
    left: 20,
    zIndex: 10,
  },
});
