import React, { useState } from 'react';
import { View, Text, StyleSheet, Modal, TouchableOpacity, Alert, Animated } from 'react-native';
import { Video } from 'expo-av';
import { LinearGradient } from 'expo-linear-gradient';

export default function HomePage({ navigation }) {
  const [popupShown, setPopupShown] = useState(false);
  const [buttonAnimation] = useState(new Animated.Value(1));

  const rulesShown = () => {
    Alert.alert(
      'How to play?',
      'Identify the five-letter word! The color of the tiles will change after each guess to indicate how near your guess was to the actual word.\n\nGreen: The right letter in the right place.\nYellow: The right letter is positioned incorrectly.\nGrey: A letter absent from the word.\nYou can guess the word six times.',
      [{ text: 'Got it!!' }]
    );
  };

  const openPopup = () => setPopupShown(true);
  const closePopup = () => setPopupShown(false);

  const onPressIn = () => {
    Animated.spring(buttonAnimation, {
      toValue: 0.95,
      useNativeDriver: true,
    }).start();
  };

  const onPressOut = () => {
    Animated.spring(buttonAnimation, {
      toValue: 1,
      useNativeDriver: true,
    }).start();
  };

  const animatedStyle = {
    transform: [{ scale: buttonAnimation }],
  };

  return (
    <View style={styles.container}>
      <Video
        source={require('../assets/homesbg.mp4')}
        style={styles.backgroundVideo}
        resizeMode="cover"
        isLooping
        isMuted={true}
        shouldPlay
      />
      <View style={styles.overlay}>
        <View style={styles.rulesButton}>
          <TouchableOpacity onPress={rulesShown}>
            <LinearGradient colors={['#6760b1', 'transparent', '#6760b1']} style={styles.gradientButton}>
              <Text style={styles.buttonText}>Game Instructions</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
        <Text style={styles.gameTitle}>Wordleeooooo</Text>

        <View style={styles.gameButton}>
          <Animated.View style={animatedStyle}>
            <TouchableOpacity
              onPressIn={onPressIn}
              onPressOut={onPressOut}
              style={styles.button}
              onPress={() => navigation.navigate('Game')}
            >
              <LinearGradient colors={['#ff7e5f', 'transparent']} style={styles.gradientButton}>
                <Text style={styles.buttonText}>Start Game</Text>
              </LinearGradient>
            </TouchableOpacity>
          </Animated.View>

          <Animated.View style={animatedStyle}>
            <TouchableOpacity onPress={openPopup}>
              <LinearGradient colors={['#185a9d', 'transparent']} style={styles.gradientButton}>
                <Text style={styles.buttonText}>Special Edition</Text>
              </LinearGradient>
            </TouchableOpacity>
          </Animated.View>

          <Animated.View style={animatedStyle}>
            <TouchableOpacity onPress={() => navigation.navigate('Multiplayer')}>
              <LinearGradient colors={['#ee0979', 'transparent']} style={styles.gradientButton}>
                <Text style={styles.buttonText}>Multiplayer</Text>
              </LinearGradient>
            </TouchableOpacity>
          </Animated.View>
        </View>

        <Modal transparent={true} visible={popupShown} animationType="slide" onRequestClose={closePopup}>
          <View style={styles.modalOverlay}>
            <View style={styles.modalContainer}>
              <TouchableOpacity style={styles.closeButton} onPress={closePopup}>
                <Text style={styles.closeButtonX}>X</Text>
              </TouchableOpacity>
              <Text style={styles.specialTitle}>Special Edition</Text>
              <View style={styles.specialTitleBox}>
                <TouchableOpacity onPress={() => {
                  closePopup();
                  navigation.navigate('CountryChallenge');
                }}>
                  <LinearGradient colors={['#3b8d99', 'transparent']} style={styles.gradientButton}>
                    <Text style={styles.buttonText}>Country Edition</Text>
                  </LinearGradient>
                </TouchableOpacity>
                <TouchableOpacity onPress={() => {
                  closePopup();
                  navigation.navigate('Timer');
                }}>
                  <LinearGradient colors={['#56ab2f', 'transparent']} style={styles.gradientButton}>
                    <Text style={styles.buttonText}>Timer Edition</Text>
                  </LinearGradient>
                </TouchableOpacity>
                <TouchableOpacity onPress={() => {
                  closePopup();
                  navigation.navigate('HangmanChallenge');
                }}>
                  <LinearGradient colors={['#b64f83', 'transparent']} style={styles.gradientButton}>
                    <Text style={styles.buttonText}>Hangman Edition</Text>
                  </LinearGradient>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'transparent',
  },
  backgroundVideo: {
    ...StyleSheet.absoluteFillObject,
    zIndex: -1,
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
  },
  rulesButton: {
    position: 'absolute',
    top: 40,
    right: 20,
  },
  gameTitle: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#fff',
    textShadowColor: 'rgba(0, 0, 0, 0.5)',
    textShadowOffset: { width: -1, height: 1 },
    textShadowRadius: 10,
  },
  gameButton: {
    width: '80%',
    marginTop: 30,
    alignItems: 'center',
  },
  gradientButton: {
    paddingVertical: 15,
    paddingHorizontal: 40,
    borderRadius: 30,
    shadowColor: '#000',
    shadowOffset: { width: 2, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
    marginBottom: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    textShadowColor: 'rgba(0, 0, 0, 0.9)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 3,
  },
  modalOverlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContainer: {
    width: '80%',
    padding: 20,
    backgroundColor: '#fff',
    borderRadius: 10,
    alignItems: 'center',
  },
  closeButton: {
    position: 'absolute',
    top: 10,
    right: 10,
  },
  closeButtonX: {
    fontSize: 18,
    color: '#000',
  },
  specialTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  specialTitleBox: {
    width: '100%',
  },
});
