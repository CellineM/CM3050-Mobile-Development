import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Alert,
  Dimensions,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  Modal,
  Image,
} from 'react-native';

import AsyncStorage from '@react-native-async-storage/async-storage';
import { Audio, Video } from 'expo-av';

const { width, height } = Dimensions.get('window');

export default function GameScreen({ navigation }) {
  const [targetWord, setTargetWord] = useState('');
  const [currentInput, setCurrentInput] = useState('');
  const [guesses, setGuesses] = useState([]);
  const [shownMessage, setShownMessage] = useState('');
  const [wordFetched, setWordFetched] = useState([]);
  const [hintType, setHintType] = useState('');
  const [hintIndex, setHintIndex] = useState(0);
  const [letterHints, setLetterHints] = useState({});
  const [currentScore, setCurrentScore] = useState(0);
  const [highScore, setHighScore] = useState(0);
  const [popup, setPopup] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [currentLevel, setCurrentLevel] = useState(1);
  const [highestLevel] = useState(100);
  const maxGuesses = 6;
  const [mainGameSound, setMainGameSound] = useState(null);
  const [gameOverSound, setGameOverSound] = useState(null);

  const [letterHintsLeft, setLetterHintsLeft] = useState(3);
  const [keyboardHintsLeft, setKeyboardHintsLeft] = useState(3);

  const [hintPopup, setHintPopup] = useState(false);
  const [hintMessage, setHintMessage] = useState('');

  useEffect(() => {
    fetchWordsForNewGame();
  }, [currentLevel]);

  useEffect(() => {
    const storeHighScore = async () => {
      try {
        const savedHighScore = await AsyncStorage.getItem('highScore');
        if (savedHighScore !== null) {
          setHighScore(parseInt(savedHighScore, 10));
        }
      } catch (error) {
        console.error('Error loading high score', error);
      }
    };
    storeHighScore();
  }, []);

  const playGameMusic = async () => {
    try {
      const { sound } = await Audio.Sound.createAsync(
        require('../assets/mainGame.mp3'),
        { shouldPlay: true, isLooping: true }
      );
      setMainGameSound(sound);
      await sound.playAsync();
    } catch (error) {
      console.error('Error playing main game sound', error);
    }
  };

  useEffect(() => {
    playGameMusic();
    return () => {
      if (mainGameSound) {
        mainGameSound.stopAsync();
      }
    };
  }, []);

  useEffect(() => {
    if (gameOver) {
      const playGameOverSound = async () => {
        try {
          if (mainGameSound) {
            await mainGameSound.stopAsync();
          }
          const { sound } = await Audio.Sound.createAsync(
            require('../assets/gameover.mp3')
          );
          setGameOverSound(sound);
          await sound.playAsync();
        } catch (error) {
          console.error('Error playing game over sound', error);
        }
      };
      playGameOverSound();
    }
  }, [gameOver, mainGameSound]);

  const fetchWordsForNewGame = () => {
    fetch('https://api.datamuse.com/words?sp=?????&max=1000&md=f&fw=g')
      .then((response) => response.json())
      .then((data) => {
        const filteredWords = data
          .filter(
            (word) =>
              word.word.length === 5 && /^[A-Z]+$/.test(word.word.toUpperCase())
          )
          .map((word) => word.word.toUpperCase());

        setWordFetched(filteredWords);
        setTargetWord(
          filteredWords[Math.floor(Math.random() * filteredWords.length)]
        );
        setGuesses([]);
        setCurrentInput('');
        setShownMessage('');
        setHintIndex(0);
        setLetterHints({});
        setGameOver(false);
      })
      .catch((error) => {
        Alert.alert('Error fetching words', error.message); // Use error.message instead of error.shownMessage
      });
  };

  const updateHighScore = async (newScore) => {
    setHighScore(newScore);
    try {
      await AsyncStorage.setItem('highScore', newScore.toString());
    } catch (error) {
      console.error('Error saving high score', error);
    }
  };

  const handleGuess = () => {
    if (currentInput.length !== 5) {
      setShownMessage('Only enter a 5-letter word.');
      return;
    }

    setGuesses([...guesses, currentInput]);
    setCurrentInput('');

    if (currentInput === targetWord) {
      const newScore = currentScore + 1;
      setCurrentScore(newScore);

      if (newScore > highScore) {
        updateHighScore(newScore);
      }

      setTimeout(() => {
        setShownMessage('Congratulations! It is the right word!!');

        if (currentLevel < highestLevel) {
          setCurrentLevel((prevLevel) => prevLevel + 1);
        } else {
          setShownMessage('CONGRATULATIONSSSSS all levels completed!!');
          setGameOver(true);
          setPopup(true);
        }
      }, 1000);
    } else if (guesses.length === maxGuesses - 1) {
      setShownMessage(`Game Over! The word was ${targetWord}`);
      setGameOver(true);
      setPopup(true);
    }
  };

  const giveHint = (type) => {
    if (type === 'letter' && targetWord) {
      if (letterHintsLeft > 0 && hintIndex < targetWord.length) {
        setHintType(type);
        setHintIndex(hintIndex + 1);
        setLetterHintsLeft((prev) => prev - 1);
        setHintMessage(`The word starts with ${targetWord.charAt(0)}`);
        setHintPopup(true);
        setTimeout(() => {
          setHintPopup(false);
        }, 1500);
      } else {
        setShownMessage('No more hints available.');
      }
    } else if (type === 'keyboard' && keyboardHintsLeft > 0) {
      const fullLetters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
      const usedLetters = new Set(targetWord.split(''));
      const newLetterHints = {};

      fullLetters.forEach((letter) => {
        newLetterHints[letter] = !usedLetters.has(letter);
      });

      setLetterHints(newLetterHints);
      setHintType(type);
      setKeyboardHintsLeft((prev) => prev - 1);
    } else {
      setShownMessage('No more keyboard hints available.');
    }
  };

  const handleLetterPress = (letter) => {
    if (currentInput.length < 5) {
      setCurrentInput((prev) => prev + letter);
    }
  };

  const handleErase = () => {
    setCurrentInput((prev) => prev.slice(0, -1));
  };

  const handleSubmit = () => {
    handleGuess();
  };

  const handleRestart = async () => {
    if (mainGameSound) {
      await mainGameSound.stopAsync();
    }
    if (gameOverSound) {
      await gameOverSound.stopAsync();
    }
    setCurrentScore(0);
    setCurrentLevel(1);
    setLetterHintsLeft(3);
    setKeyboardHintsLeft(3);
    fetchWordsForNewGame();
    setPopup(false);
    await playGameMusic();
  };

  const handleHome = async () => {
    if (mainGameSound) {
      await mainGameSound.stopAsync();
    }
    navigation.navigate('Home');
  };

  const renderGuessRow = (guess) => {
    const letters = guess ? guess.split('') : ['', '', '', '', ''];

    return (
      <View style={styles.guessRow}>
        {letters.map((letter, index) => (
          <Text
            key={index}
            style={[styles.letter, getLetterFeedback(letter, index, guess)]}>
            {letter}
          </Text>
        ))}
      </View>
    );
  };

  const getLetterFeedback = (letter, index, guess) => {
    if (!letter) return {};

    if (targetWord[index] === letter) {
      return styles.correct;
    }

    if (targetWord.includes(letter)) {
      const correctCountInTarget = targetWord.split(letter).length - 1;
      const correctCountInGuess =
        guess.slice(0, index + 1).split(letter).length - 1;
      if (correctCountInGuess <= correctCountInTarget) return styles.present;
    }

    return styles.absent;
  };

  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

  const renderHintButtons = () => (
    <View style={styles.hintContainer}>
      <TouchableOpacity
        style={styles.hintButton}
        onPress={() => giveHint('letter')}>
        <Image
          source={require('../assets/eye.png')}
          style={styles.hintIcon}
          resizeMode="contain"
        />
        <Text style={styles.hintCounter}>{letterHintsLeft}</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.hintButton}
        onPress={() => giveHint('keyboard')}>
        <Image
          source={require('../assets/hint.png')}
          style={styles.hintIcon}
          resizeMode="contain"
        />
        <Text style={styles.hintCounter}>{keyboardHintsLeft}</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      keyboardVerticalOffset={0.1 * height}>
      <View style={styles.innerContainer}>
        <TouchableOpacity style={styles.backButton} onPress={handleHome}>
          <Image
            source={require('../assets/backArrow.png')}
            style={styles.backButtonImage}
            resizeMode="contain"
          />
        </TouchableOpacity>

        <Video
          source={require('../assets/neonSquares.mp4')}
          style={styles.backgroundVideo}
          resizeMode="cover"
          isLooping
          isMuted={true}
          shouldPlay
        />

        <Text style={styles.title}>Wordle Clone</Text>
        <FlatList
          data={[...guesses, ...Array(maxGuesses - guesses.length).fill(null)]}
          renderItem={({ item }) => renderGuessRow(item)}
          keyExtractor={(item, index) => index.toString()}
        />
        <View style={styles.inputContainer}>
          <Text style={styles.currentInput}>{currentInput}</Text>
        </View>
        <View style={styles.keyboard}>
          {alphabet.map((letter) => (
            <TouchableOpacity
              key={letter}
              style={[
                styles.letterButton,
                letterHints[letter] ? styles.dull : styles.active,
              ]}
              onPress={() => handleLetterPress(letter)}
              disabled={letterHints[letter]}>
              <Text style={styles.letterButtonText}>{letter}</Text>
            </TouchableOpacity>
          ))}
          <TouchableOpacity style={styles.letterButton} onPress={handleErase}>
            <Text style={styles.letterButtonText}>⌫</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.letterButton} onPress={handleSubmit}>
            <Text style={styles.letterButtonText}>➡</Text>
          </TouchableOpacity>
          {renderHintButtons()}
        </View>
        <View style={styles.hintContainer}>
          <Text style={styles.currentScore}>Score: {currentScore}</Text>
        </View>
        <Text style={styles.shownMessage}>{shownMessage}</Text>

        <Modal
          transparent={true}
          visible={popup}
          onRequestClose={() => setPopup(false)}>
          <View style={styles.modalContainer}>
            <View style={styles.modalBlackBackground}>
              <Text style={styles.modalTitle}>
                {gameOver ? 'Game Over' : 'Congratulations!'}
              </Text>
              <Text style={styles.modalMessage}>
                Your final score is {currentScore}.
              </Text>
              <Text style={styles.modalMessage}>
                Your high score is {highScore}.
              </Text>
              <TouchableOpacity
                style={styles.whiteButton}
                onPress={handleRestart}>
                <Text style={styles.blackButtonText}>Restart</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.whiteButton} onPress={handleHome}>
                <Text style={styles.blackButtonText}>Home</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>

        <Modal
          transparent={true}
          visible={hintPopup}
          onRequestClose={() => setHintPopup(false)}>
          <View style={styles.hintPopupBox}>
            <View style={styles.hintPopupContent}>
              <Text style={styles.hintPopupWords}>{hintMessage}</Text>
            </View>
          </View>
        </Modal>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  backgroundVideo: {
    ...StyleSheet.absoluteFillObject,
    zIndex: -1,
  },
  innerContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
    paddingBottom: 0,
  },
  title: {
    fontSize: 0.07 * width,
    fontWeight: 'bold',
    marginBottom: 0.02 * width,
    textAlign: 'center',
    color: '#fff',
  },
  guessRow: {
    flexDirection: 'row',
    marginBottom: 0.01 * width,
  },
  letter: {
    width: 0.1 * width,
    height: 0.1 * width,
    textAlign: 'center',
    textAlignVertical: 'center',
    fontSize: 0.05 * width,
    fontWeight: 'bold',
    borderColor: '#ddd',
    borderWidth: 2,
    margin: 2,
    backgroundColor: '#fff',
  },
  correct: {
    backgroundColor: '#6aaa64',
    color: '#fff',
  },
  present: {
    backgroundColor: '#c9b458',
    color: '#fff',
  },
  absent: {
    backgroundColor: '#787c7e',
    color: '#fff',
  },
  inputContainer: {
    marginTop: 0.02 * width,
  },
  currentInput: {
    fontSize: 0.05 * width,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 0.02 * width,
    color: '#fff',
  },
  keyboard: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    marginBottom: 0.1 * width,
  },
  letterButton: {
    width: 0.1 * width,
    height: 0.1 * width,
    margin: 2,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 4,
    backgroundColor: '#fff',
    borderColor: '#000',
    borderWidth: 1,
  },
  letterButtonText: {
    fontSize: 0.04 * width,
    fontWeight: 'bold',
    color: '#000',
  },
  dull: {
    backgroundColor: '#aaa',
  },
  active: {
    backgroundColor: '#ddd',
  },
  hintContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 10,
    alignItems: 'center',
  },
  hintButton: {
    width: 0.1 * width,
    height: 0.1 * width,
    margin: 2,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fff',
    borderRadius: 4,
    borderWidth: 2,
    borderColor: '#ddd',
    position: 'relative',
  },
  hintIcon: {
    width: '75%',
    height: '75%',
  },
  hintCounter: {
    position: 'absolute',
    top: 0,
    right: 0,
    backgroundColor: '#ff0000',
    color: '#fff',
    borderRadius: 10,
    padding: 2,
    fontSize: 0.03 * width,
  },

  backButton: {
    position: 'absolute',
    top: 20,
    left: 20,
    zIndex: 1,
  },
  backButtonImage: {
    width: 30,
    height: 30,
    tintColor: '#fff',
  },
  currentScore: {
    fontSize: 0.04 * width,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center',
    marginTop: 0.005 * height,
  },
  shownMessage: {
    marginTop: 12,
    fontSize: 0.04 * width,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#fff',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalBlackBackground: {
    width: 0.8 * width,
    backgroundColor: '#000',
    padding: 20,
    borderRadius: 10,
    alignItems: 'center',
  },

  modalTitle: {
    fontSize: 0.05 * width,
    fontWeight: 'bold',
    color: '#fff',
  },

  modalMessage: {
    fontSize: 0.04 * width,
    marginVertical: 10,
    color: '#fff',
  },
  whiteButton: {
    backgroundColor: '#fff',
    padding: 10,
    borderRadius: 5,
    width: '80%',
    alignItems: 'center',
    marginVertical: 10,
  },

  blackButtonText: {
    color: '#000',
    fontSize: 0.04 * width,
    fontWeight: 'bold',
  },
  hintPopupBox: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.7)',
  },
  hintPopupContent: {
    width: 0.7 * width,
    padding: 20,
    backgroundColor: '#333',
    borderRadius: 10,
  },
  hintPopupWords: {
    color: '#fff',
    fontSize: 0.05 * width,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
