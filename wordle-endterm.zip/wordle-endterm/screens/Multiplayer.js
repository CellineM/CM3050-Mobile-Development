import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  Button,
  StyleSheet,
  FlatList,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Dimensions,
  TouchableOpacity,
  TextInput,
  Image,
} from 'react-native';

const { width } = Dimensions.get('window');
const keyboardKeySize = width * 0.07; // Correct variable name

export default function MultiplayerPage({ navigation }) {
  const [gameId, setGameId] = useState(null); // Stores the unique identifier for the current game
  const [playerId, setPlayerId] = useState('player1'); // Stores the ID of the current player (defaulting to 'player1')
  const [currentInput, setCurrentInput] = useState(''); // Stores the current guess input by the player
  const [guessesMade, setGuessesMade] = useState([]); // Stores the list of all guesses made so far
  const [targetWord, setTargetWord] = useState(''); // Stores the target word that players are trying to guess
  const [currentPlayer, setCurrentPlayer] = useState('player1'); // Tracks whose turn it currently is (defaulting to 'player1')
  const [gameOver, setGameOver] = useState(false); // Tracks whether the game is over or still in progress
  const [isLoading, setIsLoading] = useState(true); // Tracks whether the game data is still loading

  useEffect(() => {
    const initialize = async () => {
      try {
        const wordleWord = await fetchRandomWord();
        if (!wordleWord) {
          Alert.alert('Error! Could not fetch any word.');
          setIsLoading(false);
          return;
        }

        setTargetWord(wordleWord.toUpperCase());
        setIsLoading(false);
      } catch (error) {
        console.error('Initialization Error:', error);
        Alert.alert('Error', 'An error occurred while initializing the game.');
        setIsLoading(false);
      }
    };

    initialize();
  }, []);

  const fetchRandomWord = async () => {
    try {
      let wordleWord = '';
      do {
        const response = await fetch(
          'https://random-word-form.herokuapp.com/random/noun'
        );
        const data = await response.json();
        wordleWord = data[0].toUpperCase();
      } while (wordleWord.length > 7); // Continue fetching if the word is longer than 7 letters

      return wordleWord;
    } catch (error) {
      console.error('API Error:', error);
      return 'ERROR'; // Fallback word in case of API error
    }
  };

  const handleGameGuesses = () => {
    if (currentInput.length !== targetWord.length) {
      Alert.alert(
        'Not Valid',
        `Please enter a ${targetWord.length}-letter word.`
      );
      return;
    }

    const totalTries = guessesMade.filter(
      (guess) => guess.player === currentPlayer
    ).length;

    if (totalTries >= 3) {
      Alert.alert(
        'No more tries left',
        `${currentPlayer} has used all tries.`
      );
      return;
    }

    const newTries = [
      ...guessesMade,
      { player: currentPlayer, wordleWord: currentInput.toUpperCase() },
    ];
    setGuessesMade(newTries);

    if (currentInput.toUpperCase() === targetWord) {
      Alert.alert(
        'Congratulations!',
        `${currentPlayer} guessed the correct word!`
      );
      setGameOver(true);
    } else {
      const allGuesses = newTries.length;
      if (allGuesses >= 6) {
        setGameOver(true);
      } else {
        setCurrentPlayer(currentPlayer === 'player1' ? 'player2' : 'player1');
      }
    }

    setCurrentInput('');
  };

  const handleHome = () => {
    navigation.navigate('Home');
  };

  const handleLetterPress = (letter) => {
    if (currentInput.length < targetWord.length) {
      setCurrentInput((prev) => prev + letter);
    }
  };

  const handleBackspace = () => {
    setCurrentInput((prev) => prev.slice(0, -1));
  };

  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
  const wordleBoxSize =
    targetWord.length <= 6 ? width * 0.1 : width * (0.8 / targetWord.length);

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      {/* Back Button */}
      <TouchableOpacity style={styles.backButton} onPress={handleHome}>
        <Image
          source={require('../assets/backArrow.png')} // Path to your back arrow image
          style={styles.backButtonImage}
          resizeMode="contain"
        />
      </TouchableOpacity>

      <Text style={styles.title}>Multiplayer</Text>
      <Text style={styles.subtitle}>
        {gameOver ? 'Game Over :(' : `Current Turn: ${currentPlayer.toUpperCase()}`}
      </Text>

      <FlatList
        data={guessesMade}
        renderItem={({ item }) => {
          const letters = item.wordleWord.split('');
          const targetLetters = targetWord.split('');

          const colorBox = Array(targetWord.length).fill('#787c7e'); // Default to grey for incorrect letters
          const targetLetterCounts = {};

          letters.forEach((letter, index) => {
            if (letter === targetLetters[index]) {
              colorBox[index] = '#6aaa64'; // Green for correct position
            } else {
              if (targetLetters[index] in targetLetterCounts) {
                targetLetterCounts[targetLetters[index]]++;
              } else {
                targetLetterCounts[targetLetters[index]] = 1;
              }
            }
          });

          letters.forEach((letter, index) => {
            if (colorBox[index] !== '#6aaa64' && targetLetterCounts[letter]) {
              colorBox[index] = '#c9b458'; // Yellow for correct letter, wrong position
              targetLetterCounts[letter]--;
            }
          });

          return (
            <View style={styles.guessRow}>
              <Text style={styles.whichPlayer}>
                {item.player === 'player1' ? '*' : '-'}
              </Text>
              {letters.map((letter, index) => (
                <View
                  key={index}
                  style={[
                    styles.letterBox,
                    {
                      width: wordleBoxSize,
                      height: wordleBoxSize,
                      backgroundColor: colorBox[index],
                    },
                  ]}>
                  <Text
                    style={[styles.letterText, { fontSize: wordleBoxSize * 0.5 }]}>
                    {letter}
                  </Text>
                </View>
              ))}
            </View>
          );
        }}
        keyExtractor={(item, index) => index.toString()}
        contentContainerStyle={styles.guessesContainer}
        ListFooterComponent={() =>
          Array.from({ length: 6 - guessesMade.length }).map((_, index) => (
            <View key={`empty-${index}`} style={styles.guessRow}>
              <Text style={styles.whichPlayer}> </Text>
              {Array.from({ length: targetWord.length }).map((_, boxIndex) => (
                <View
                  key={`box-${boxIndex}`}
                  style={[
                    styles.letterBox,
                    { width: wordleBoxSize, height: wordleBoxSize },
                  ]}>
                  <Text
                    style={[
                      styles.letterText,
                      { fontSize: wordleBoxSize * 0.5 },
                    ]}></Text>
                </View>
              ))}
            </View>
          ))
        }
      />

      {!gameOver && (
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.textInput}
            value={currentInput}
            onChangeText={setCurrentInput}
            maxLength={targetWord.length}
            placeholder={`Enter ${targetWord.length}-letter word`}
            placeholderTextColor="#d7dadc"
            autoCapitalize="characters"
          />

          {/* Alphabet Keyboard */}
          <View style={styles.keyboard}>
            {alphabet.map((letter) => (
              <TouchableOpacity
                key={letter}
                style={[
                  styles.letterButton,
                  { width: keyboardKeySize, height: keyboardKeySize },
                ]}
                onPress={() => handleLetterPress(letter)}>
                <Text
                  style={[
                    styles.letterButtonText,
                    { fontSize: keyboardKeySize * 0.5 },
                  ]}>
                  {letter}
                </Text>
              </TouchableOpacity>
            ))}
            <TouchableOpacity
              style={[
                styles.letterButton,
                styles.backspaceButton,
                { width: keyboardKeySize * 2 },
              ]}
              onPress={handleBackspace}>
              <Text
                style={[
                  styles.letterButtonText,
                  { fontSize: keyboardKeySize * 0.5 },
                ]}>
                ⌫
              </Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.submitButton} onPress={handleGameGuesses}>
              <Text style={styles.letterButtonText}>➡</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      {gameOver && (
        <View style={styles.gameOverContainer}>
          <Text style={styles.gameOverText}>
            The word was: {targetWord.toUpperCase()}
          </Text>
          <Button
            title="Restart"
            onPress={() => navigation.replace('Multiplayer')}
            color="#6aaa64"
          />
          <Button title="Home" onPress={handleHome} color="#d7dadc" />
        </View>
      )}
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  // Container Style
  container: {
    flex: 1,
    backgroundColor: '#121213',
    padding: 20,
    paddingTop: Platform.OS === 'android' ? 40 : 60, // Adjust based on platform, with a larger value for iOS
  },

  // Back Button Styles
  backButton: {
    position: 'absolute',
    top: 20,
    left: 20,
    zIndex: 1,
  },
  backButtonImage: {
    width: 30,
    height: 30,
    tintColor: '#fff', // White color for the arrow
  },

  // Title and Subtitle Styles
  title: {
    fontSize: width * 0.08,
    color: '#ffffff',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  subtitle: {
    fontSize: width * 0.05,
    color: '#d7dadc',
    textAlign: 'center',
    marginVertical: 10,
  },

  // Guess Container and Row Styles
  guessesContainer: {
    alignItems: 'center',
    marginVertical: 20,
  },
  guessRow: {
    flexDirection: 'row',
    marginVertical: 5,
    alignItems: 'center',
  },

  // Letter Box and Text Styles
  letterBox: {
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 4,
    backgroundColor: '#3a3a3c',
    margin: 3,
  },
  letterText: {
    color: '#ffffff',
    fontWeight: 'bold',
  },

  // Player Indicator Style
  whichPlayer: {
    fontSize: width * 0.1, // Slightly larger indicator size
    color: '#d7dadc',
    marginRight: 7, // Space between indicator and boxes
  },

  // Input Container and TextInput Styles
  inputContainer: {
    alignItems: 'center',
    marginTop: 30,
  },
  textInput: {
    width: '60%',
    height: 40,
    borderColor: '#3a3a3c',
    borderWidth: 1,
    color: '#ffffff',
    textAlign: 'center',
    borderRadius: 5,
    backgroundColor: '#3a3a3c',
    marginBottom: 10,
  },

  // Keyboard and Button Styles
  keyboard: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    marginTop: 20,
  },
  letterButton: {
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 4,
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#121213',
  },
  letterButtonText: {
    fontWeight: 'bold',
    color: '#121213',
  },
  backspaceButton: {
    width: keyboardKeySize * 2, // Same width as the Submit button
    height: keyboardKeySize, // Same height as the Submit button
  },
  submitButton: {
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 4,
    backgroundColor: '#6aaa64',
    borderWidth: 1,
    borderColor: '#121213',
    marginTop: 1,
    width: keyboardKeySize * 2, // Made wider to be more prominent
    height: keyboardKeySize, // Made taller to be more prominent
  },

  // Game Over Container and Text Styles
  gameOverContainer: {
    alignItems: 'center',
    marginVertical: 20,
  },
  gameOverText: {
    fontSize: width * 0.06,
    color: '#d7dadc',
    marginBottom: 10,
  },
});
