

# Country Guessing Game

## Overview

The **Country Guessing Game** is a mobile application that challenges players to guess the name of a randomly selected country. The game features a limited number of attempts and provides visual feedback on the accuracy of each guess. Players must guess the correct country name within six attempts.

## Features

- **Random Country Selection:** The app fetches a random country with a name length of 7 letters or less from an external API.
- **Interactive Gameplay:** Players guess the country name by selecting letters from an on-screen keyboard. 
- **Visual Feedback:** Letters are color-coded based on correctness:
  - Green: Correct letter in the correct position.
  - Yellow: Correct letter but in the wrong position.
  - Gray: Incorrect letter.