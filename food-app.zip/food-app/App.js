import React, { useState, useContext } from 'react';
import { NavigationContainer, useNavigation, useRoute } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
// importing the cell, section, and tableview components from rect native tableview simple to create the table view for the food app
import { Cell, Section, TableView } from 'react-native-tableview-simple';
import { StyleSheet, ScrollView, Image, Text, View, TouchableOpacity } from 'react-native';


function Restaurants() {
  //
  let tableData = [
    {
      // representing the different restaurant menu item
      cells: [
        {
          // Name of the food restaurant
          title: "Joe's Gelato",
          // tagline
          tagline: 'Desert, Ice cream, £££',
          eta: '10-30', // time estimation for delivery
          imgUri: require('./assets/gelato.jpg'), // image of the restaurant shown
          // menu representing different food sections of the menu
          menu: [
            {
              // Gelato is the title of the menu section
              title: 'Gelato',
              contents: [
                {
                  title: 'Vanilla',
                  // different options of the item (vanilla)
                  options: [
                    // options of the item with details: price, and also the availability.
                    // if its available, the image of the vanilla scoop will be shown.
                    { option: '1 Scoop', price: '£2.00', 
                    imgUri: require('./assets/vanilla.jpg'), availability: true },
                    { option: '2 Scoop', price: '£4.50', 
                    imgUri: require('./assets/vanilla.jpg'), availability: true  },
                    { option: '3 Scoop', price: '£5.00', 
                    imgUri: require('./assets/vanilla.jpg'), availability: true  },
                    { option: '1 Tub', price: '£8.00', 
                    imgUri: require('./assets/vanilla.jpg'), availability: true },
                  ],
                },
                {
                  title: 'Chocolate',
                  options: [
                    { option: '1 Scoop', price: '£2.00', 
                    imgUri: require('./assets/chocolate.jpg'), availability: true  },
                    { option: '2 Scoop', price: '£4.50', 
                    imgUri: require('./assets/chocolate.jpg'), availability: true  },
                    { option: '3 Scoop', price: '£5.00', 
                    imgUri: require('./assets/chocolate.jpg'), availability: true  },
                    { option: '1 Tub', price: '£8.00', 
                    imgUri: require('./assets/chocolate.jpg'), availability: false  },
                    // availability: false, when its false, the picture of out of stock will be shown
                  ],
                },
                {
                  title: 'Mint',
                  options: [
                    { option: '1 Scoop', price: '£2.00', 
                    imgUri: require('./assets/mint.jpg'), availability: true },
                    { option: '2 Scoop', price: '£4.50', 
                    imgUri: require('./assets/mint.jpg'), availability: true },
                    { option: '3 Scoop', price: '£5.00', 
                    imgUri: require('./assets/mint.jpg'), availability: true },
                    { option: '1 Tub', price: '£8.00', 
                    imgUri: require('./assets/mint.jpg'), availability: true },
                  ],
                },
                {
                  title: 'Oreo Bueno',
                  options: [
                    { option: '1 Scoop', price: '£2.00', 
                    imgUri: require('./assets/oreoBueno.jpg'), availability: true },
                    { option: '2 Scoop', price: '£4.50', 
                    imgUri: require('./assets/oreoBueno.jpg'), availability: true },
                    { option: '3 Scoop', price: '£5.00', 
                    imgUri: require('./assets/oreoBueno.jpg'), availability: true },
                    { option: '1 Tub', price: '£8.00', 
                    imgUri: require('./assets/oreoBueno.jpg'), availability: true },
                  ],
                },
                {
                  title: 'Choco Chip',
                  options: [
                    { option: '1 Scoop', price: '£2.00', 
                    imgUri: require('./assets/choc-chip.jpg'), availability: true },
                    { option: '2 Scoop', price: '£4.50', 
                    imgUri: require('./assets/choc-chip.jpg'), availability: true },
                    { option: '3 Scoop', price: '£5.00', 
                    imgUri: require('./assets/choc-chip.jpg'), availability: true },
                    { option: '1 Tub', price: '£8.00', 
                    imgUri: require('./assets/choc-chip.jpg'), availability: true},
                  ],
                },
              ],
            },
            {
              title: 'Coffee',
              contents: [
                {
                  title: 'Flat White',
                  options: [
                    { option: 'Regular Milk', price: '£2.50', 
                    imgUri: require('./assets/flatWhite.jpg'), availability: true },
                    { option: 'Oat Milk', price: '£3.50', 
                    imgUri: require('./assets/flatWhite.jpg'), availability: true },
                    { option: 'Soy Milk', price: '£3.00', 
                    imgUri: require('./assets/flatWhite.jpg'), availability: true },
                  ],
                },
                { 
                  title: 'Latte',
                  options: [
                    { option: 'Regular Milk', price: '£3.00', 
                    imgUri: require('./assets/Latte.jpg'), availability: true },
                    { option: 'Oat Milk', price: '£4.00', 
                    imgUri: require('./assets/Latte.jpg'), availability: true },
                    { option: 'Soy Milk', price: '£4.00', 
                    imgUri: require('./assets/Latte.jpg'), availability: true},
                  ]
                },
                { title: 'Caffe Americano',
                options: [
                  {option: 'Regular', price: '£3.50', 
                    imgUri: require('./assets/cappuccino.jpg'), availability: true},
                  {option: 'Less Shot', price: '£3.50', 
                    imgUri: require('./assets/cappuccino.jpg'), availability: true},
                  {option: 'Extra Shot', price: '£4.50', 
                    imgUri: require('./assets/cappuccino.jpg'), availability: true},
                ] },
                { title: 'Cappucino',
                options: [
                  { option: 'Regular Milk', price: '£3.50', 
                    imgUri: require('./assets/cappuccino.jpg'), availability: true },
                  { option: 'Oat Milk', price: '£4.50', 
                    imgUri: require('./assets/cappuccino.jpg'), availability: true },
                  { option: 'Soy Milk', price: '£4.50', 
                    imgUri: require('./assets/cappuccino.jpg'), availability: true },
                ] },
              ],
            },
            {
              title: 'Sundaes',
              contents: [
                { 
                  title: 'Banana Split',
                  options: [
                    { option: 'Banana Split', price: '£5.00'},
                  ],
                },
                { 
                  title: 'Oreo Nutchunks',
                  options: [
                    { option: 'Oreo Nutchunks', price: '£5.50', 
                    imgUri: require('./assets/OreoNutChunks.jpg'), availability: true},
                    { option: 'Vanilla Gelato', availability: true},
                    { option: 'Oreo Gelato', availability: true},
                    { option: 'Whipped Cream', availability: true},
                    { option: 'Nuts', availability: true},
                    { option: 'Kit-Kat Chunks', availability: true},
                    { option: 'Nuts', price: '£0.30', availability: true},
                    { option: 'Kinder Bueno', price: '£1.50', availability: true},
                    { option: 'Whipped Cream', price: '£0.80', availability: true},
                    { option: 'Extra Scoop of Gelato', price: '£1.50', availability: true}
                  ],
                },
                { 
                  title: 'Parfait',
                  options: [
                    { option: 'Parfait', price: '£5.50', 
                    imgUri: require('./assets/parfait.jpg'), availability: true},
                    { option: 'Vanilla Gelato', availability: true},
                    { option: 'Matcha Gelato', availability: true},
                    { option: 'Strawberries', availability: true},
                    { option: 'Nuts', availability: true},
                    { option: 'Chocolate Syrup', availability: true},
                    { option: 'Strawberry Syrup', availability: true},
                    { option: 'Kinder Bueno', price: '£1.50', availability: true},
                    { option: 'Whipped Cream', price: '£0.80', availability: true},
                    { option: 'Extra Scoop of Gelato', price: '£1.50', availability: true}
                  ],
                },
                { 
                  title: 'Affogato Sundae',
                  options: [
                    { option: 'Affogato Sundae', price: '£4.80', availability: false},

                  ],
                },
              ],
            },
          ],
        },
        {
          title: "Joe's Diner",
          tagline: 'American, burgers, £££',
          eta: '50+',
          imgUri: require('./assets/food1.jpg'),
          menu: [
            {
              title: 'Starters',
              contents: [
                { title: 'Buffalo Wings',
                options: [
                  {option: 'Buffalo Wings', price: '£6.00', 
                    imgUri: require('./assets/buffaloWings.jpg'), availability: true},
                  {option: 'Spice Level: ', availability: true},
                  {option: 'Level 😔', availability: true, 
                    imgUri: require('./assets/buffaloWings.jpg')},
                  {option: 'Level 😊', availability: true, 
                    imgUri: require('./assets/buffaloWings.jpg')},
                  {option: 'Level 🔥', availability: true, 
                    imgUri: require('./assets/buffaloWings.jpg')},
                  {option: 'Level 🤯', availability: true, 
                    imgUri: require('./assets/buffaloWings.jpg')},
                ]},
                { title: 'Mozarella Sticks',
                options: [
                  {option: '3pcs', price: '£4.50'},
                  {option: '6pcs', price: '£5.50'},
                  {option: '9pcs', price: '£6.50'}
                ]},
                { title: 'Brisket Burnt Ends',
                options:[
                  {option: '300g', price: '£8.50'},
                  {option: '500g', price: '£10.50'},
                  {option: '700g', price: '£12.50'}
                  
                ] },
                { title: 'Cheesy Garlic Bread',
                options:[
                  {option: '2pcs', price: '£2.50', 
                    imgUri: require('./assets/garlicbread.jpg'), availability: true},
                  {option: '3pcs', price: '£3.50', 
                    imgUri: require('./assets/garlicbread.jpg'), availability: true},
                  {option: '5pcs', price: '£5.00', 
                    imgUri: require('./assets/garlicbread.jpg'), availability: true},
                  {option: 'Extra Cheese', price: '£1.00', 
                    imgUri: require('./assets/garlicbread.jpg'), availability: true},
                ] },
              ],
            },
            {
              title: 'Burgers',
              contents: [
                { title: 'Cheesy Melts Burger',
                options: [
                  {option: 'Ala-Carte', price: '£6.50', 
                    imgUri: require('./assets/cheesyMelt.jpg'), availability: true},
                  {option: 'Set Menu', price: '£8.50', 
                    imgUri: require('./assets/cheesyMelt.jpg'), availability: true},
                  {option: 'Sides (Choose 2)', availability: true},
                  {option: 'Chips', availability: true},
                  {option: 'Mashed Potato', availability: true},
                  {option: 'Salad', availability: false},
                  {option: 'Extra Cheese', availability: true}
                ] },

                { title: 'Pulled Pork Burger',
                options: [
                  {option: 'Ala-Carte', price: '£7.50', 
                    imgUri: require('./assets/pulledPork.jpg'), availability: true},
                  {option: 'Set Menu', price: '£9.50', 
                    imgUri: require('./assets/pulledPork.jpg'), availability: true},
                  {option: 'Sides (Choose 2)', availability: true},
                  {option: 'Chips', availability: true},
                  {option: 'Mashed Potato', availability: true},
                  {option: 'Salad', availability: false},
                  {option: 'Extra Cheese', availability: true}
                ] },

                { title: 'Lamb Burger',
                options: [
                  {option: 'Ala-Carte', price: '£7.50', 
                    imgUri: require('./assets/lambBurger.jpg'), availability: true},
                  {option: 'Set Menu', price: '£9.50', 
                    imgUri: require('./assets/lambBurger.jpg'), availability: true},
                  {option: 'Sides (Choose 2)', availability: true},
                  {option: 'Chips', availability: true},
                  {option: 'Mashed Potato', availability: true},
                  {option: 'Salad', availability: false},
                  {option: 'Extra Cheese', availability: true}
                ] },
              ],
            },
            {
              title: 'Drinks',
              contents: [
                { title: 'Lemonade',
                options: [
                  {option: 'Small', price: '£2.50', 
                    imgUri: require('./assets/lemonade.jpg'), availability: true},
                  {option: 'Medium', price: '£3.50', 
                    imgUri: require('./assets/lemonade.jpg'), availability: true},
                  {option: 'Large', price: '£4.50', 
                    imgUri: require('./assets/lemonade.jpg'), availability: true}
                ]},
                { title: 'Root Beer',
                option: [
                  {option: 'Small', price: '£2.50', 
                    imgUri: require('./assets/rootbeer.jpg'), availability: true},
                  {option: 'Medium', price: '£3.50', 
                    imgUri: require('./assets/rootbeer.jpg'), availability: true},
                  {option: 'Large', price: '£4.50', 
                    imgUri: require('./assets/rootbeer.jpg'), availability: true},
                  {option: '1 Scoop of Gelato', price: '£1.00', 
                    imgUri: require('./assets/vanilla.jpg'), availability: true}
                ] },
                { title: 'Soda Float',
                options: [
                  {option: 'Small', price: '£2.50', 
                    imgUri: require('./assets/sodaFloat.jpg'), availability: true},
                  {option: 'Medium', price: '£3.50', 
                    imgUri: require('./assets/sodaFloat.jpg'), availability: true},
                  {option: 'Large', price: '£4.50', 
                    imgUri: require('./assets/sodaFloat.jpg'), availability: true},
                  {option: '1 Scoop of Gelato', price: '£1.00', 
                    imgUri: require('./assets/vanilla.jpg'), availability: true}
                ] },
                { title: 'Water',
                options: [

                  {option: 'Sparkling (Bottle)', price: '£2.50', 
                    imgUri: require('./assets/water.jpg'), availability: true},
                  {option: 'Still (Bottle)', price: '£2.00', 
                    imgUri: require('./assets/water.jpg'), availability: true},
                ] },
              ],
            },
          ],
        },
        {
          title: 'Viet Viet Yum',
          tagline: 'Vietnamese, Noodles, £',
          eta: '20-40',
          imgUri: require('./assets/vietnam.jpg'),
          menu: [
            {
              title: 'Appetizers',
              contents: [
                { title: 'Prawn Crackers',
                options: [
                  {option: 'Prawn Cracker', price:'£3.00', 
                    imgUri: require('./assets/prawnCrackers.jpg'), availability: true},
                  {option: 'Original'},
                  {option: 'Spicy'}
                ]},
                { title: 'Papaya Salad',
                options: [
                  {option: 'Original', price:'£6.00', 
                    imgUri: require('./assets/papaya.jpg'), availability: true},
                  {option: 'Fermented Crab', price:'£6.00', 
                    imgUri: require('./assets/papaya.jpg'), availability: true},
                  {option: 'Seafood', price:'£8.00', 
                    imgUri: require('./assets/papaya.jpg'), availability: true},
                  {option: 'Salmon', price:'£9.00', availability: false},
                ]},
                { title: 'Fried spring roll',
                options: [
                  {option: '3pcs', price:'£5.00', 
                    imgUri: require('./assets/springroll.jpg'), availability: true},
                  {option: '5pcs', price:'£7.00', 
                    imgUri: require('./assets/springroll.jpg'), availability: true},
                  {option: '10pcs', price:'£10.00', 
                    imgUri: require('./assets/springroll.jpg'), availability: true},
                ]},
                { title: 'Cockles',
                options: [
                  {option: '100g', price:'£6.00', 
                    imgUri: require('./assets/cockles.jpg'), availability: true},
                  {option: '300g', price:'£9.00', 
                    imgUri: require('./assets/cockles.jpg'), availability: true},
                  {option: '500g', price:'£12.00', 
                    imgUri: require('./assets/cockles.jpg'), availability: true},
                ] },
              ],
            },
            {
              title: 'Noodles',
              contents: [
                { title: 'Chicken Pho',
                options: [
                  {option: 'Chicken Pho', price:'£10.00', 
                    imgUri: require('./assets/pho.jpg'), availability: true},
                  {option: 'No Mint Leaves', availability: true},
                  {option: 'No Red Onion', availability: false},
                  {option: 'No Bean Sprout', availability: true},
                  {option: 'No Fried Onion', availability: true}
                ] },
                { title: 'Bun Bo Hue',
                options: [
                  {option: 'Bun Bo Hue', price:'£10.00', 
                    imgUri: require('./assets/bunBoHue.jpg'), availability: true},
                  {option: 'No Mint Leaves', availability: true},
                  {option: 'No Red Onion', availability: false},
                  {option: 'No Bean Sprout', availability: true},
                  {option: 'No Fried Onion', availability: true}
                ]  },
                { title: 'Prawn Noodle',
                options: [
                  {option: 'Prawn Noodle', price:'£10.00', 
                    imgUri: require('./assets/prawnNoodle.jpg'), availability: true},
                  {option: 'No Mint Leaves', availability: true},
                  {option: 'No Red Onion', availability: false},
                  {option: 'No Bean Sprout', availability: true},
                  {option: 'No Fried Onion', availability: true}
                ]  },
              ],
            },
            {
              title: 'Drinks',
              contents: [
                { title: 'Viet Coffee',
                options: [
                  {option: 'Small', price:'£4.00', 
                    imgUri: require('./assets/vietCoffee.jpg'), availability: true},
                  {option: 'Large', price:'£6.00', 
                    imgUri: require('./assets/vietCoffee.jpg'), availability: true},
                ]},
                { title: 'Saigon Lemonade',
                options: [
                  {option: 'Small', price:'£3.50', 
                    imgUri: require('./assets/saigonLemon.jpg'), availability: true},
                  {option: 'Medium', price: '£4.50', 
                    imgUri: require('./assets/saigonLemon.jpg'), availability: true},
                  {option: 'Large', price:'£5.50', 
                    imgUri: require('./assets/saigonLemon.jpg'), availability: true},
                ] },
                { title: 'Lemongrass Tea',
                options: [
                  {option: 'Small', price:'£4.00', 
                    imgUri: require('./assets/lemongrass.jpg'), availability: true},
                  {option: 'Medium', price: '£5.00', 
                    imgUri: require('./assets/lemongrass.jpg'), availability: true},
                  {option: 'Large', price:'£6.00', 
                    imgUri: require('./assets/lemongrass.jpg'), availability: true},
                ] },
              ],
            },
          ],
        },
      ],
    },
  ];

  const navigation = useNavigation();

  const HomeScreenCell = (props) => (
    <Cell
    // make the background colour of the food app to transparent
      backgroundColor="transparent"
      onPress={props.onPress}
      cellAccessoryView={
        <View style={props.customStyle}>
          <Image style={props.imageStyle} source={props.imageSrc} />
          {/* the styles for the estimation arrival label */}  
          <View
            style={{
              width: 100,
              height: 60,
              borderRadius: 50,
              backgroundColor: 'white',
              justifyContent: 'center',
              position: 'absolute',
              right: 0,
              marginTop: 170,
              marginRight: 20,
            }}>
            <Text
              style={{ fontSize: 17, fontWeight: 'bold', textAlign: 'center' }}>
              {props.etaLabel} {/* render the estimation arrival text passed in the props */}
            </Text>
            <Text
              style={{
                fontSize: 17,
                fontWeight: 'bold',
                textAlign: 'center',
                marginTop: -5,
              }}>
              mins
            </Text>
          </View>
          {/* render the custom label with all the styles passed in the props */}
          <Text style={props.customLabelStyle}>{props.customLabel}</Text>
          {/* render the sub label with all the styles passed in the props */}
          <Text style={props.customSubLabelStyle}>{props.customSubLabel}</Text>
        </View>
      }
    />
  );

  return (
    <View style={styles.container}>
      <ScrollView>
        <TableView>
          {tableData.map((section, i) => (
            <Section key={i} hideSeparator="false" separatorTintColor="#ccc">
              {section.cells.map((cell, i) => (
                <HomeScreenCell
                  key={i}
                  etaLabel={cell.eta}
                  customLabel={cell.title}
                  customLabelStyle={{
                    marginTop: 5,
                    fontSize: 20,
                    fontWeight: 'bold',
                  }}
                  customSubLabel={cell.tagline}
                  customSubLabelStyle={{ marginTop: 5, fontSize: 14 }}
                  customStyle={{
                    width: '100%',
                    height: 290,
                    backgroundColor: 'transparent',
                    marginLeft: 2,
                  }}
                  imageSrc={cell.imgUri}
                  imageStyle={{ width: '100%', height: 200, borderRadius: 5 }}
                  onPress={() =>
                    navigation.navigate('Menu', { items: cell.menu })
                  }
                />
              ))}
            </Section>
          ))}
        </TableView>
      </ScrollView>
    </View>
  );
}

function Menu() {
  //using react navigation to access the route object
  const route = useRoute();
  const items = route.params.items;
  // to get navigation object
  const navigation = useNavigation();

  return (
    // the page will scroll once the height of the screen has exceeds
    <ScrollView style={styles.container}>
      <TableView appearance="light">
        {items.map((section, index) => (
          <Section key={index} header={section.title}>
            {section.contents.map((item, idx) => (
              <Cell
                key={idx}
                title={item.title}
                // once pressed, it will lead to menu choices page
                onPress={() => navigation.navigate('MenuChoices', { item })}
              />
            ))}
          </Section>
        ))}
      </TableView>
    </ScrollView>
  );
}

function MenuChoices() {
  const route = useRoute();
  const { item } = route.params;
  // initialize with empty array
  // setchosenextra to update the chosen extra state, chosenExtra is defined to keep track of the selected options from the menu choices.
  const [chosenExtra, setChosenExtra] = useState([]);

  const toggleExtra = (option) => {
    // to update the state
    setChosenExtra((prev) =>
    // checking if option is already inside the chosenExtra array
      prev.includes(option)
      // if yes remove from the chosen Extra, if not add the option into the chosenExtra array
        ? prev.filter((t) => t !== option)
        : [...prev, option]
    );
  };

  return (
    <ScrollView style={styles.container}>
      <TableView appearance="light">
      {/* header set to the item's title */} 
        <Section header={item.title}>
          {item.options.map((option, idx) => (
            <Cell key={idx}>
            {/*apply the styles into touchable opacity, if the option is not available, show the outofstock image */ } 
              <TouchableOpacity
                style={[styles.cellContainer, !option.availability && styles.outOfStock]}
                onPress={() => option.availability && toggleExtra(option.option)}
                // if the option is not available, the user would not be able to click or choose that option
                disabled={!option.availability}>
                <Image source = {option.availability ? option.imgUri: require('./assets/outOfStock.png')}
                style = {styles.foodPicture}/>
                <Text style={styles.cellName}>{option.option}</Text>
                <Text style={styles.cellPrice}>{option.price}</Text>
                {chosenExtra.includes(option.option) && (
                  <Text style={styles.selectedIndicator}>✓</Text>
                )}
              </TouchableOpacity>
            </Cell>
          ))}
        </Section>
      </TableView>
    </ScrollView>
  );
}

const Stack = createNativeStackNavigator();

function App() {

  return (
    // to navigate the state
      <NavigationContainer>
        <Stack.Navigator>
          <Stack.Screen
          // use restaurants components
            name="Restaurants "
            component={Restaurants}
            options={{ title: 'Restaurants', headerTitleAlign: 'center' }}
          />
          <Stack.Screen
          // use menu components
            name="Menu"
            component={Menu}
            options={{ title: 'Menu', headerTitleAlign: 'center' }}
          />
          <Stack.Screen
          // use menuChoices component
            name="MenuChoices"
            component={MenuChoices}
            options={{ title: 'Choices', headerTitleAlign: 'center' }}
          />
        </Stack.Navigator>
      </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ecf0f1',
  },
  cellContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 10,
  },
  cellName: {
    fontWeight: 'bold',
  },
  cellPrice: {
    marginLeft: 'auto',
  },
  selectedIndicator: {
    marginLeft: 10,
    color: 'green',
    fontWeight: 'bold',
    fontSize: 20,
  },

  outOfStock: {
    backgroundColor: '#ddd',
  },

  foodPicture: {
    width: 110,
    height: 110,
    marginRight: 15,
    marginBottom: 30

  }

});

export default App;
