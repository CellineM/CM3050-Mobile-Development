import React, { useState } from 'react';
import { StyleSheet, View, Text, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
// export the delete icon from expo
import Feather from '@expo/vector-icons/Feather'; 

export default function App() {
  const [shownNum, setShownNum] = useState("0");
  const [arithmetic, setArithmetic] = useState("");
  const [history, setHistory] = useState([]);

// when the button is pressed
  const buttonPressed = (value) => {
    if (value === "=") {
      try {
        // replace the x and the ÷ with the actual multiplication and division
        const outcome = eval(arithmetic.replace("x", "*").replace("÷", "/"));
        setShownNum(outcome.toString());
        // update to the new calculation
        setHistory((prevHistory) => [
          ...prevHistory, `${arithmetic} = ${outcome}`,
        ]);
        setArithmetic(outcome.toString());
      } catch (error) {
        setShownNum("ERR😔");
      }
      // when C is pressed, the screen will reset
    } else if (value === "C") {
      setShownNum("0");
      setArithmetic("");
      setHistory([]);
    } else if (value === "+/-") {
      // Switch the current arithmetic signs
      setArithmetic((prevArithmetic) =>
        prevArithmetic.charAt(0) === '-' ? prevArithmetic.slice(1) : `-${prevArithmetic}`
      );
    } else if (value === "%") {
      try {
        // the latest number, calculate the %
        const latestNumShown = arithmetic.match(/(\d+\.?\d*)$/);
        if (latestNumShown) {
          const latestNumber = latestNumShown[0];
          const laterPercent = eval(`${latestNumber} / 100`);
          setArithmetic(arithmetic.replace(latestNumber, laterPercent));
        } else {
          const outcome = eval(arithmetic + "/100");
          setShownNum(outcome.toString());
          setArithmetic(outcome.toString());
        }
      } catch (error) {
        setShownNum("ERR😔");
      }
      // delete the latest number/arithmetic from the arithmetic expression
    } else if (value === "delete") {
      setArithmetic((prevArithmetic) =>
        prevArithmetic.length > 0 ? prevArithmetic.slice(0, -1) : prevArithmetic
      );
      // Add the pressed number to the mathematical expression.
    } else {
      setArithmetic((prevArithmetic) =>
        prevArithmetic === "0" ? value.toString() : prevArithmetic + value
      );
    }
  };

  return (
    // Make the whole background into a gradient colour (linearly)
    <LinearGradient colors={['#73deba', '#deb373', '#8d60b5', '#dbb8db']} style={styles.gradient}>
      <View style={styles.container}>
        <View style={styles.displayContainer}>
          {/*show the result*/}
          <Text
            style={styles.equationText}
            adjustsFontSizeToFit={true}
            minimumFontScale={0.5}
          >
            {arithmetic || shownNum}
          </Text>
        </View>

        {/*delete button*/} 
        <TouchableOpacity style={styles.erase} onPress={() => buttonPressed("delete")}>
          <Feather name="delete" size={30} color="black" />
        </TouchableOpacity>

        {/* 1st row from the top*/} 
        <View style={styles.row}>
          <TouchableOpacity style={styles.buttonRow1} onPress={() => buttonPressed("C")}>
            <Text style={styles.buttonText}>C</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.buttonRow1} onPress={() => buttonPressed("+/-")}>
            <Text style={styles.buttonText}>+/-</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.buttonRow1} onPress={() => buttonPressed("%")}>
            <Text style={styles.buttonText}>%</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.buttonRow1, styles.buttonBlue]} onPress={() => buttonPressed("÷")}>
            <Text style={[styles.buttonText, styles.buttonTextWhite]}>÷</Text>
          </TouchableOpacity>
        </View>

        {/* 2nd row */} 
        <View style={styles.row}>
          <TouchableOpacity style={styles.button} onPress={() => buttonPressed("7")}>
            <Text style={[styles.buttonText, styles.buttonTextWhite]}>7</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.button} onPress={() => buttonPressed("8")}>
            <Text style={[styles.buttonText, styles.buttonTextWhite]}>8</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.button} onPress={() => buttonPressed("9")}>
            <Text style={[styles.buttonText, styles.buttonTextWhite]}>9</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.button, styles.buttonBlue]} onPress={() => buttonPressed("x")}>
            <Text style={[styles.buttonText, styles.buttonTextWhite]}>x</Text>
          </TouchableOpacity>
        </View>

        {/* 3rd row */} 
        <View style={styles.row}>
          <TouchableOpacity style={styles.button} onPress={() => buttonPressed("4")}>
            <Text style={[styles.buttonText, styles.buttonTextWhite]}>4</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.button} onPress={() => buttonPressed("5")}>
            <Text style={[styles.buttonText, styles.buttonTextWhite]}>5</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.button} onPress={() => buttonPressed("6")}>
            <Text style={[styles.buttonText, styles.buttonTextWhite]}>6</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.button, styles.buttonBlue]} onPress={() => buttonPressed("-")}>
            <Text style={[styles.buttonText, styles.buttonTextWhite]}>-</Text>
          </TouchableOpacity>
        </View>

        {/* 4th row */} 
        <View style={styles.row}>
          <TouchableOpacity style={styles.button} onPress={() => buttonPressed("1")}>
            <Text style={[styles.buttonText, styles.buttonTextWhite]}>1</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.button} onPress={() => buttonPressed("2")}>
            <Text style={[styles.buttonText, styles.buttonTextWhite]}>2</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.button} onPress={() => buttonPressed("3")}>
            <Text style={[styles.buttonText, styles.buttonTextWhite]}>3</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.button, styles.buttonBlue]} onPress={() => buttonPressed("+")}>
            <Text style={[styles.buttonText, styles.buttonTextWhite]}>+</Text>
          </TouchableOpacity>
        </View>

        {/* Last row */} 
        <View style={styles.row}>
          <TouchableOpacity style={[styles.button, styles.buttonZero]} onPress={() => buttonPressed("0")}>
            <Text style={[styles.buttonText, styles.buttonTextZero]}>0</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.button} onPress={() => buttonPressed(".")}>
            <Text style={[styles.buttonText, styles.buttonTextWhite]}>.</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.button, styles.buttonBlue]} onPress={() => buttonPressed("=")}>
            <Text style={[styles.buttonText, styles.buttonTextWhite]}>=</Text>
          </TouchableOpacity>
        </View>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  gradient: {
    flex: 1,
  },
  container: {
    flex: 1,
    paddingHorizontal: 8,
    paddingBottom: 8,
  },
  displayContainer: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'flex-end', // the number align on the right side of the calculator
    marginBottom: 16, // how far the displayed number from the bottom of that container
  },
  equationText: {
    fontSize: 64, // size of the number/arithmetic shown
    maxWidth: '100%', //max width of the characters
    maxHeight: '80%', // max height of the characters
    flexWrap: 'wrap', // wrap the characters when the characters exceed the countainer area
    color: '#000080', // the colour of the text
    textAlign: 'right', // align the text to the right side of the screen
  },
  row: {
    flexDirection: 'row',
    marginBottom: 8,
  },
  button: {
    flex: 1, // the button have equal space 
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(69,69,69,0.4)', // 0.4 - the opacity of that colour chosen
    borderWidth: 3,
    borderColor: '#454545',
    marginHorizontal: 4,
    height: 70,
    borderRadius: 160,
  },
  buttonRow1: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(125, 177, 181, 0.3)',
    borderWidth: 3,
    borderColor: '#7db1b5',
    marginHorizontal: 4,
    height: 70,
    borderRadius: 160,
  },
  buttonBlue: {
    backgroundColor: "rgba(150, 98, 92, 0.4)",
    borderWidth: 3,
    borderColor: "#96625c",
  },
  buttonText: {
    fontSize: 30,
    color: '#000', // colour of the text of the button
  },
  buttonTextWhite: {
    color: "#fff",
  },
  buttonZero: {
    flex: 2, // the button for 0 take double the space
    justifyContent: "center",
    alignItems: "flex-start",
    paddingLeft: 40,
  },
  buttonTextZero: {
    color: "#fff",
    textAlign: "left",
  },
  erase: {
    justifyContent: 'center',
    alignItems: 'flex-end',
    marginBottom: 13,
  },
});
   
