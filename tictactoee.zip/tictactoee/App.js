import { StyleSheet, Text, View, Image } from 'react-native';
// Import necessary components from 'react-native'

export default function App() {
  return (
    <View style={styles.container}>
      {/* Main container view */}
      
      {/* Tic tac toe first row */}
      <View style={styles.row}>

        {/* First row cell, column 1 */}
        <View style={[styles.cell, styles.borderBottom, styles.borderRight]}>
          <Text style={styles.emoji}>🫧</Text>
        </View>

        {/* First row cell, column 2 */}
        <View style={[styles.cell, styles.borderBottom, styles.borderRight]}>
          <Text style={styles.emoji}>🫧</Text>
        </View>

        {/* First row cell, column 3 */}
        <View style={[styles.cell, styles.borderBottom]}>
          {/* Image to show the letter X */}
          <Image source={require('./image/letter-x.png')} style={styles.letterX}/>
        </View>

      </View>

      {/* Tic tac toe second row */}
      <View style={styles.row}> 

        {/* Second row cell, column 1 */}
        <View style={[styles.cell, styles.borderRight]}>
          <Image source={require('./image/letter-x.png')} style={styles.letterX}/>
        </View>

        {/* Second row cell, column 2 */}
        <View style={[styles.cell, styles.borderRight]}>
          <Text style={styles.emoji}>🫧</Text>
        </View>

        {/* Second row cell, column 3 */}
        <View style={styles.cell}>
          <Text style={styles.emoji}>🫧</Text>
        </View>

      </View>

      {/* Tic tac toe third row */}
      <View style={styles.row}> 

        {/* Third row cell, column 1 */}
        <View style={[styles.cell, styles.borderTop, styles.borderRight]}>
          <Image source={require('./image/letter-x.png')} style={styles.letterX}/>
        </View>

        {/* Third row cell, column 2 */}
        <View style={[styles.cell, styles.borderTop, styles.borderRight]}>
          <Image source={require('./image/letter-x.png')} style={styles.letterX}/>
        </View>

        {/* Third row cell, column 3 */}
        <View style={[styles.cell, styles.borderTop]}>
          <Text style={styles.emoji}>🫧</Text>
        </View>

      </View>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black', // Background color of the container
    alignItems: 'center', // Center horizontally
    justifyContent: 'center', // Center vertically
    padding: 10, 
  },
  row: {
    flexDirection: 'row', // Arrange items in a row
    width: '100%', 
    justifyContent: 'center', // Center items horizontally
    alignItems: 'center', // Center items vertically
  },
  cell: {
    flex: 1,
    aspectRatio: 1, // Make cells square by setting the aspect ratio to 1
    justifyContent: 'center', // Center content vertically
    alignItems: 'center', // Center content horizontally
  },
  borderBottom: {
    borderBottomColor: 'white', // Color of the bottom border
    borderBottomWidth: 4, // Width of the bottom border
  },
  borderRight: {
    borderRightColor: 'white', // Color of the right border
    borderRightWidth: 4, // Width of the right border
  },
  borderTop: {
    borderTopColor: 'white', // Color of the top border
    borderTopWidth: 4, // Width of the top border
  },
  emoji: {
    fontSize: 60, // Font size for the emoji
  },
  letterX: {
    width: '80%', // Width of the X image relative to the cell
    height: '80%', // Height of the X image relative to the cell
    resizeMode: 'contain', // Ensure the image is within the screen size
  },
});
