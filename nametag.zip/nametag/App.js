import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, SafeAreaView } from 'react-native';
import * as ScreenOrientation from 'expo-screen-orientation';
import {useFonts} from 'expo-font';
import {LinearGradient} from 'expo-linear-gradient'; 
import { Image } from 'react-native';

// importing the file of the font
import nameFonts from './assets/nameFont.ttf';
import bigFonts from './assets/Nicolast.ttf';
import salsaIcon from './assets/salsa.png';

export default function App() {

  ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LANDSCAPE_LEFT);

  // loading the font inside (any place you want)
  const [fontInside] = useFonts
  ({
    nameFonts: nameFonts,
    bigFonts: bigFonts
  });
  //if the font is not inside the return null
  if(!fontInside) 
  {
    return null;
  }

  return (
    // the colour to make the gradient
    <LinearGradient colors={['#73deba', '#45a6b5', '#8d60b5']} 
    style = {styles.gradientCol}>
      
    <SafeAreaView style={{ flex: 1, width: "100%", height: "100%"}}>
    <View style={styles.container}>

      <Text style = {[styles.welcomeText, fontInside && {fontFamily: 'bigFonts'}]}> Hello</Text>

      <View style={styles.containerR}>
        <Image source={salsaIcon} style={styles.salsaIcon}/>
        <Text style={styles.subtitleText}>My name is </Text>
        <Image source={salsaIcon} style={styles.salsaIcon}/>
      </View>

      {/* to create a box with the name inside*/}
      <View style = {styles.nameBox}>
        <Text style = {[styles.nameText, fontInside && {fontFamily: 'nameFonts'}]}>
          💃 Celline Maccabee 💃</Text>
      </View>

      <StatusBar style="auto" />
    </View>
    </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({

  gradientCol:
  {
    flex: 1
  },

  container: 
  {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center'
  },

  // R = row
  containerR: 
  {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20
  },


  welcomeText: 
  {
    fontSize: 90,
    textTransform: 'uppercase',
    color: 'white',
    textAlign: 'center',
    marginRight: 15
  },

  subtitleText: 
  {
    fontSize: 30,
    textTransform: 'uppercase',
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
    marginLeft: 15
    },

  nameBox: 
  {
    width: "90%", 
    height: "40%", 
    backgroundColor: "rgba(172, 157, 201, 0.5)", 
    borderRadius: 15, 
    justifyContent:"center",
    borderColor: 'white',
    borderWidth: 1.5
  },

  nameText: 
  {
    fontSize: 60, 
    textAlign: "center"
  },

  salsaIcon:
  {
    width: 45,
    height: 45

  }

});


